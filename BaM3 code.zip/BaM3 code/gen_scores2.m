function gen_scores2(Np)

% Generate the score metrics - part 2

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set the parameters for comparison
uncs = 'nv';   % Select the unmodelable case
fk_icond = 25; % Set the initial condition - t_0 (25: 2y; 13: 1y) 
thr = 0.05;    % Set the threshold for comparison
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

pval_vec = [0.01, 0.025, 0.05, 0.075, 0.1]; % Vector of alpha values 
tec_vec = [1, 3, 6, 9, 12]; % Vector of prediction times t_p

NSiml = Np; % number of patients

for itec = 1:length(tec_vec)
    for ialp = 1:length(pval_vec)
        
        fk_econd = tec_vec(itec); % set t_p

        tfl_pval = pval_vec(ialp); % tolerance to obtain the modelable pdf

        % Load the dataset
        load(strcat('./DTfiles_nv/fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), 'DT.mat'), 'tfl_ec', 'tms_ec');
        
        load(strcat('./MODELABLE_DISTS_nv/MODDIST_fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), '_pval', num2str(tfl_pval), '.mat'), 'tfl_range', 'tms_range', 'q');

        load(strcat('./UNMODELABLE_DISTS_', uncs, '/UNMODDIST_fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), '.mat'), 'a');
        
        load(strcat('./FINAL_DISTS_', uncs, '/FINDIS_fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), '_pval', num2str(tfl_pval), '.mat'), 'pfin');


        for i=1:NSiml

            %% Find the mode
            [maxq, ~] = max(q{i}(:));
            [imIWq, imTMq] = find(q{i} == maxq);
            mIWq = (tfl_range(imIWq));
            mTMq = (tms_range(imTMq));

            [maxpf, ~] = max(pfin{i}(:));
            [imIWpf, imTMpf] = find(pfin{i} == maxpf);
            mIWpf = (tfl_range(imIWpf));
            mTMpf = (tms_range(imTMpf));
            
            
            %% Calculate the variance
            % For q{i} (i.e. the modelable pdf)
            x = tms_range;
            y = tfl_range;
            Exq = trapz(x, x .* trapz(y,q{i},1));
            Eyq = trapz(y, y .* trapz(x,q{i},2)');

            tempq = repmat(x-Exq, size(q{i},1), 1);
            Sxxq = trapz(x, x.^2 .* trapz(y,q{i},1)) - Exq^2;
            Syyq = trapz(y, y.^2 .* trapz(x,q{i},2)') - Eyq^2;
            Sxyq = trapz(y, (y-Eyq) .* trapz(x, tempq.*q{i} , 2)');

            Sq = [Sxxq, Sxyq; Sxyq, Syyq];
            Sqdet{ialp,itec}(i) = det(Sq);
            
            % For pfin{i} (i.e. the BaM3 pdf)
            Exf = trapz(x, x .* trapz(y,pfin{i},1));
            Eyf = trapz(y, y .* trapz(x,pfin{i},2)');

            tempf = repmat(x-Exf, size(pfin{i},1), 1);
            Sxxf = trapz(x, x.^2 .* trapz(y,pfin{i},1)) - Exf^2;
            Syyf = trapz(y, y.^2 .* trapz(x,pfin{i},2)') - Eyf^2;
            Sxyf = trapz(y, (y-Eyf) .* trapz(x, tempf.*pfin{i} , 2)');

            Sf = [Sxxf, Sxyf; Sxyf, Syyf];
            Sfdet{ialp,itec}(i) = det(Sf);
            
            %%
            % Evaluate the non dimensional error between the full model values and the ones obtained from the distributions
            Dmq{ialp,itec}(i) = mean(sqrt(1/2.*((1 - mTMq./tms_ec(1,i) ).^2  + (1 - mIWq./tfl_ec(1,i) ).^2)));
            Dmf{ialp,itec}(i) = mean(sqrt(1/2.*((1 - mTMpf./tms_ec(1,i)).^2  + (1 - mIWpf./tfl_ec(1,i)).^2)));
            
            % Evaluate the partial errors
            DmTMq{ialp,itec}(i) = mean(sqrt( (1 - mTMq./tms_ec(1,i)  ).^2 ));
            DmTMf{ialp,itec}(i) = mean(sqrt( (1 - mTMpf./tms_ec(1,i) ).^2 ));
            DmIWq{ialp,itec}(i) = mean(sqrt( (1 - mIWq./tfl_ec(1,i)  ).^2 ));
            DmIWf{ialp,itec}(i) = mean(sqrt( (1 - mIWpf./tfl_ec(1,i) ).^2 ));
            
        end

        % Count the number of improved predictions
        ieq = find(abs(Dmf{ialp,itec}(:) - Dmq{ialp,itec}(:)) <= thr * Dmq{ialp,itec}(:)); % No change
        ide = find(Dmf{ialp,itec}(:) > (1 + thr) * Dmq{ialp,itec}(:));    % Deterioration of prediction
        iim = find(Dmf{ialp,itec}(:) < (1 - thr) * Dmq{ialp,itec}(:));    % Improvement of prediction

        % Calculate the scores
        Smeq(ialp,itec) = length(ieq) / NSiml;
        Smde(ialp,itec) = length(ide) / NSiml;
        Smim(ialp,itec) = length(iim) / NSiml;
        
        % Save the indeces in a cell array
        Imeq{ialp,itec} = ieq;
        Imde{ialp,itec} = ide;
        Imim{ialp,itec} = iim;
    
        clear ieq ide iim mIWq mTMq mIWpf mTMpf
    end
end

% Save scores at fixed alpha
alp_fix = 0.05;
ialp = find(pval_vec == alp_fix);
Smim_vec = Smim(ialp, :);
Smeq_vec = Smeq(ialp, :);
Smde_vec = Smde(ialp, :);

for j=1:length(tec_vec) % Export the distances at fixed alpha
    Dmqaf{1,j} = Dmq{ialp,j}; 
    Dmfaf{1,j} = Dmf{ialp,j};
end

% Save results
save(strcat('./scores_', uncs, '/ScoresM_thr', num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'Dmf', 'Dmq', 'Smeq', 'Smim', 'Smde', 'pval_vec', 'tec_vec');
save(strcat('./scores_', uncs, '/ScoresM_TMqfIWqf_thr', num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'DmTMq', 'DmTMf', 'DmIWq', 'DmIWf');
save(strcat('./scores_', uncs, '/PatientsIdM_thr', num2str(thr), '_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'Imeq', 'Imde', 'Imim');
save(strcat('./scores_', uncs, '/ScoresM_thr', num2str(thr), '_fki', num2str(fk_icond), 'fixalp', num2str(alp_fix), '_te', sprintf('%d_', tec_vec), '.mat'), 'Smim_vec', 'Smeq_vec', 'Smde_vec', 'Dmqaf', 'Dmfaf');
save(strcat('./scores_', uncs, '/ScoresS_thr', num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'Sfdet', 'Sqdet');

%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set the parameters for comparison
uncs = 'nv';   % Select the unmodelable case
fk_icond = 13; % Set the initial condition - t_0 (25: 2y; 13: 1y) 
thr = 0.05;    % Set the threshold for comparison
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

pval_vec = [0.01, 0.025, 0.05, 0.075, 0.1]; % Vector of alpha values 
tec_vec = [1, 3, 6, 9, 12]; % Vector of prediction times t_p

for itec = 1:length(tec_vec)
    for ialp = 1:length(pval_vec)
        
        fk_econd = tec_vec(itec); % set t_p

        tfl_pval = pval_vec(ialp); % tolerance to obtain the modelable pdf

        % Load the dataset
        load(strcat('./DTfiles_nv/fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), 'DT.mat'), 'tfl_ec', 'tms_ec');
        
        load(strcat('./MODELABLE_DISTS_nv/MODDIST_fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), '_pval', num2str(tfl_pval), '.mat'), 'tfl_range', 'tms_range', 'q');

        load(strcat('./UNMODELABLE_DISTS_', uncs, '/UNMODDIST_fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), '.mat'), 'a');
        
        load(strcat('./FINAL_DISTS_', uncs, '/FINDIS_fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), '_pval', num2str(tfl_pval), '.mat'), 'pfin');


        for i=1:NSiml
            
            %% Find the mode
            [maxq, ~] = max(q{i}(:));
            [imIWq, imTMq] = find(q{i} == maxq);
            mIWq = (tfl_range(imIWq));
            mTMq = (tms_range(imTMq));

            [maxpf, ~] = max(pfin{i}(:));
            [imIWpf, imTMpf] = find(pfin{i} == maxpf);
            mIWpf = (tfl_range(imIWpf));
            mTMpf = (tms_range(imTMpf));

            %% Calculate the variance
            % For q{i}
            x = tms_range;
            y = tfl_range;
            Exq = trapz(x, x .* trapz(y,q{i},1));
            Eyq = trapz(y, y .* trapz(x,q{i},2)');

            tempq = repmat(x-Exq, size(q{i},1), 1);
            Sxxq = trapz(x, x.^2 .* trapz(y,q{i},1)) - Exq^2;
            Syyq = trapz(y, y.^2 .* trapz(x,q{i},2)') - Eyq^2;
            Sxyq = trapz(y, (y-Eyq) .* trapz(x, tempq.*q{i} , 2)');

            Sq = [Sxxq, Sxyq; Sxyq, Syyq];
            Sqdet{ialp,itec}(i) = det(Sq);
            
            % For pfin{i}
            Exf = trapz(x, x .* trapz(y,pfin{i},1));
            Eyf = trapz(y, y .* trapz(x,pfin{i},2)');

            tempf = repmat(x-Exf, size(pfin{i},1), 1);
            Sxxf = trapz(x, x.^2 .* trapz(y,pfin{i},1)) - Exf^2;
            Syyf = trapz(y, y.^2 .* trapz(x,pfin{i},2)') - Eyf^2;
            Sxyf = trapz(y, (y-Eyf) .* trapz(x, tempf.*pfin{i} , 2)');

            Sf = [Sxxf, Sxyf; Sxyf, Syyf];
            Sfdet{ialp,itec}(i) = det(Sf);            
            
            %%
            % Evaluate the nondimensional error between the full model values and the ones obtained from the distributions
            Dmq{ialp,itec}(i) = mean(sqrt(1/2.*((1 - mTMq./tms_ec(1,i) ).^2  + (1 - mIWq./tfl_ec(1,i) ).^2)));
            Dmf{ialp,itec}(i) = mean(sqrt(1/2.*((1 - mTMpf./tms_ec(1,i)).^2  + (1 - mIWpf./tfl_ec(1,i)).^2)));
            
            % Evaluate the partial errors
            DmTMq{ialp,itec}(i) = mean(sqrt( (1 - mTMq./tms_ec(1,i)  ).^2 ));
            DmTMf{ialp,itec}(i) = mean(sqrt( (1 - mTMpf./tms_ec(1,i) ).^2 ));
            DmIWq{ialp,itec}(i) = mean(sqrt( (1 - mIWq./tfl_ec(1,i)  ).^2 ));
            DmIWf{ialp,itec}(i) = mean(sqrt( (1 - mIWpf./tfl_ec(1,i) ).^2 ));
            
        end

        % Count the number of improved predictions
        ieq = find(abs(Dmf{ialp,itec}(:) - Dmq{ialp,itec}(:)) <= thr * Dmq{ialp,itec}(:)); % No change
        ide = find(Dmf{ialp,itec}(:) > (1 + thr) * Dmq{ialp,itec}(:));    % Deterioration of prediction
        iim = find(Dmf{ialp,itec}(:) < (1 - thr) * Dmq{ialp,itec}(:));    % Improvement of prediction

        % Calculate the scores
        Smeq(ialp,itec) = length(ieq) / NSiml;
        Smde(ialp,itec) = length(ide) / NSiml;
        Smim(ialp,itec) = length(iim) / NSiml;
        
        % Save the indeces in a cell array
        Imeq{ialp,itec} = ieq;
        Imde{ialp,itec} = ide;
        Imim{ialp,itec} = iim;
    
        clear ieq ide iim mIWq mTMq mIWpf mTMpf
    end
end

% Save scores at fixed alpha
alp_fix = 0.05;
ialp = find(pval_vec == alp_fix);
Smim_vec = Smim(ialp, :);
Smeq_vec = Smeq(ialp, :);
Smde_vec = Smde(ialp, :);

for j=1:length(tec_vec) % Export the distances at fixed alpha
    Dmqaf{1,j} = Dmq{ialp,j}; 
    Dmfaf{1,j} = Dmf{ialp,j};
end

% Save results
save(strcat('./scores_', uncs, '/ScoresM_thr', num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'Dmf', 'Dmq', 'Smeq', 'Smim', 'Smde', 'pval_vec', 'tec_vec');
save(strcat('./scores_', uncs, '/ScoresM_TMqfIWqf_thr', num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'DmTMq', 'DmTMf', 'DmIWq', 'DmIWf');
save(strcat('./scores_', uncs, '/PatientsIdM_thr', num2str(thr), '_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'Imeq', 'Imde', 'Imim');
save(strcat('./scores_', uncs, '/ScoresM_thr', num2str(thr), '_fki', num2str(fk_icond), 'fixalp', num2str(alp_fix), '_te', sprintf('%d_', tec_vec), '.mat'), 'Smim_vec', 'Smeq_vec', 'Smde_vec', 'Dmqaf', 'Dmfaf');
save(strcat('./scores_', uncs, '/ScoresS_thr', num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'Sfdet', 'Sqdet');

end
