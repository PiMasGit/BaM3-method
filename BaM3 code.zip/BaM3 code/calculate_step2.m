function calculate_step2(fki, fke, Np)

    
    % Select the unmodelable case
    uncs = 'nv';
    
    %---------------------------------------------------------------------%
    %#####################################################################%
    %---------------------------------------------------------------------%
    
   
    % Total number of patients
    NSiml = Np;
     
    % Set t_0 and t_p
    fk_icond = fki;
    fk_econd = fke;
    
    %---------------------------------------------------------------------%
    %#####################################################################%
    %---------------------------------------------------------------------%
    %%% Load the dataset
    load(strcat('./DTfiles_', uncs, '/fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), 'DT.mat'), 'tfl_ec', 'tms_ec', 'tfl_mec', 'tms_mec', 'tfl_mec_interp', 'tms_mec_interp', 'tfl_icond', 'tms_icond', 'nms_icond', 'vms_icond', 'tfl_td', 'tms_td', 'nms_td', 'vms_td');
    
    
%   %---------------------------------------------------------------------%
%   % STEP 2
%   %---------------------------------------------------------------------%
    
    % Create the range of values for building the distributions
    mintlf = min(min(tfl_ec), min(tfl_icond));
    maxtlf = max(max(tfl_ec), max(tfl_icond));
    
    mintms = min(min(tms_ec), min(tms_icond));
    maxtms = max(max(tms_ec), max(tms_icond));
    
    tfl_range = mintlf:((maxtlf - mintlf) / 200):maxtlf; % Divide the IW and TS range in 200 bins
    tms_range = mintms:((maxtms - mintms) / 200):maxtms;

    %%% Calculate distribution P(Xu|Y)
    % Dataset = IW, TS, ntd, vtd
    DPYXu = [tfl_td; tms_td; nms_td; vms_td]';

    % Create a grid to evaluate TS and IW in a matrix
    [iwcoord, tmcoord] = ndgrid(tfl_range, tms_range);

    % Put everything in the form of column vectors
    iwcoord = iwcoord(:);
    tmcoord = tmcoord(:);
    
    % Build the points in the (IW, TS) space in which we want the evaluation to be done
    pts_iwtm = [iwcoord, tmcoord];

    % Calculate the bandwidth to evaluate the smoother according to Silverman's rule of thumb -see MATLAB ref page on mvksdensity
    bw1 = std(DPYXu(:,1)) .* (4 / (NSiml .* (size(DPYXu,2) + 2) ) ) .^ (1 / (size(DPYXu,2) + 4));
    bw2 = std(DPYXu(:,2)) .* (4 / (NSiml .* (size(DPYXu,2) + 2) ) ) .^ (1 / (size(DPYXu,2) + 4));
    bw3 = std(DPYXu(:,3)) .* (4 / (NSiml .* (size(DPYXu,2) + 2) ) ) .^ (1 / (size(DPYXu,2) + 4));
    bw4 = std(DPYXu(:,4)) .* (4 / (NSiml .* (size(DPYXu,2) + 2) ) ) .^ (1 / (size(DPYXu,2) + 4));
    
    %hwb = waitbar(0, 'Please wait...'); % Enable to visualize a loading bar in the GUI
    for i = 1:NSiml % loop over the patients to build the unmodelable pdf structure

        % Concatenate the values of the i-th patient (NOTE: here the Xu are at time t0 !)
        pts_iwtmn0v0 = [pts_iwtm, nms_icond(i) .* ones(size(pts_iwtm,1),1), vms_icond(i) .* ones(size(pts_iwtm,1),1)];

        % Use mvksdensity to obtain the probability for each patient over the TS and IW range
        adist = mvksdensity(DPYXu, pts_iwtmn0v0, 'Bandwidth', [bw1 bw2 bw3 bw4]);

        % Reshape the evaluated probability into a matrix form
        adist_mat = reshape(adist, length(tfl_range), length(tms_range));
        
        % Normalize the distribution
        a{i} = adist_mat ./ trapz(tfl_range,trapz(tms_range,adist_mat,2));
        
        clear pts_iwtmn0v0 adist adist_mat 
        
    %waitbar(i/NSiml, hwb, sprintf('Calculating a - completed: %.2f %%', (100 * i/NSiml)));
    end % end of patient loop
    %close(hwb);
    
    
    %%% Save the a-values
    save(strcat('UNMODELABLE_DISTS_nv/UNMODDIST_fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), '.mat'), 'a');
    
        
    clear a q pfin pfin_temp
    
end