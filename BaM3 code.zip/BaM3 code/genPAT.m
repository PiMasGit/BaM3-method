function genPAT(Np)

    %---------------------------------------------------------------------%
    %#####################################################################%
    %---------------------------------------------------------------------%
    
    L     = 300;    %=> (mm) length of the domain
    xh    = 2.5e-2; %=> (mm) spatial discretization
    xmesh = 0:xh:L; %=> Discretized spatial domain
    
    %---------------------------------------------------------------------%
    
    % Set the number of patients
    NSiml = Np;
    
    %---------------------------------------------------------------------%
    %#####################################################################%
    %---------------------------------------------------------------------%

        for i = 1:NSiml
            
            for j = 1:37 % from 0 to 36 [m]

                simul_pdesys = load(strcat('CREATE_DATASET/DATASET/Simulations_pdesys/simulation_pdesys_', num2str(i), '.mat'), ...
                                           'c',  ...
                                           'n',  ...
                                           'v',  ...
                                           'Dc', ...
                                           'bc', ...
                                           'as', ...
                                           'bs', ...
                                           'h2', ...
                                           'g1', ...
                                           'g2');

                %-------------------------------------------------------------%
                % Calculate IW, TS, \bar{n}, \bar{v} at each time from the full
                % model. E.g. IW(patientID, month)

                IW_ec(i,j) = func_InfiltrationWidth(simul_pdesys.c(j,:), xmesh); 
                TM_ec(i,j) = func_Mass(simul_pdesys.c(j,:), xmesh);
                nb_ec(i,j) = func_metric(simul_pdesys.n(j,:), xmesh);
                vb_ec(i,j) = func_metric(simul_pdesys.v(j,:), xmesh);

                %-------------------------------------------------------------%

                clearvars simul_pdesys;
            end
        end
        
        % Save results
        save(strcat('./PATfiles_nv.mat'),'IW_ec','TM_ec','nb_ec','vb_ec');
    
%#########################################################################%

    function [tfl] = func_InfiltrationWidth(vals, xmesh)
        
        for k = 1:length(vals)
            if(vals(1,k) >= (0.80 * max(vals)))
                ind80 = k;
            end
        end

        for k = length(vals):-1:1
            if(vals(1,k) <= (0.02 * max(vals)))
                ind02 = k;
            end
        end
        
        tfl = xmesh(1,ind02) - xmesh(1,ind80);
    end

%#########################################################################%

    function [mass] = func_Mass(vals, xmesh)
        mass = trapz(xmesh, vals/max(vals));
    end

%#########################################################################%

    function [metric] = func_metric(vals, xmesh)
        metric = trapz(xmesh, vals); 
    end

%#########################################################################%
end