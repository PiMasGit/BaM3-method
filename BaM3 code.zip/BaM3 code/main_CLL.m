%-------------------------------------------------------------------------%
%  Application of the BaM3 method on a dataset of CLL patients            %
%                                                                         %
%  Symeon Savvopoulos                                                     %
%                                                                         %
%  E-Mail: symeon.savvopoulos@kuleuven.be                                 %
%                                                                         %  
%  Requires mvksdensity.m from the 'Statistics and Machine Learning       %
%  Toolbox'                                                               %  
%-------------------------------------------------------------------------%


clc
clear
close all

% comment 1/12: min and max values of the parameters

fw_min=3.46e-2;
fw_max=7.76e-2;


b_min=0.12e-2;
b_max=1.73e-2;

vr_min=0.001;
vr_max=0.381;


% comment 2/12: ranges of the parameters between min and max values

fw_range=[fw_min:((fw_max - fw_min) / 60):fw_max];
vr_range=[vr_min:((vr_max - vr_min) / 60):vr_max];
b_range=[b_min:((b_max - b_min) / 60):b_max];


% comment 3/12: create all combinations in the values of the parameters

x=zeros(61,61,61);

for i =1:61
    for j=1:61
     for k=1:61
    x(i,j,k)=modelss_1(fw_range(i),vr_range(j),b_range(k));
    end
    end
end


% comment 4/12: find min and max values of the output and then discretization
% of the output in 300 bins
xmin=min(min(min(x(:,:))));
xmax=max(max(max(x(:,:))));
x_range = xmin:((xmax - xmin) / 300):xmax;


%comment 5/12:  convert the 3D cell of x variable to 2D matrix
     Xmat=[x(1:61,1:61,1) x(1:61,1:61,2) x(1:61,1:61,3) x(1:61,1:61,4) x(1:61,1:61,5) x(1:61,1:61,6) x(1:61,1:61,7) x(1:61,1:61,8) x(1:61,1:61,9) x(1:61,1:61,10) ...
         x(1:61,1:61,11) x(1:61,1:61,12) x(1:61,1:61,13) x(1:61,1:61,14) x(1:61,1:61,15) x(1:61,1:61,16) x(1:61,1:61,17) x(1:61,1:61,18) x(1:61,1:61,19) x(1:61,1:61,20) ...
         x(1:61,1:61,21) x(1:61,1:61,22) x(1:61,1:61,23) x(1:61,1:61,24) x(1:61,1:61,25) x(1:61,1:61,26) x(1:61,1:61,27) x(1:61,1:61,28) x(1:61,1:61,29) x(1:61,1:61,30)...
         x(1:61,1:61,31) x(1:61,1:61,32) x(1:61,1:61,33) x(1:61,1:61,34) x(1:61,1:61,35) x(1:61,1:61,36) x(1:61,1:61,37) x(1:61,1:61,38) x(1:61,1:61,39) x(1:61,1:61,40) ...
         x(1:61,1:61,41) x(1:61,1:61,42) x(1:61,1:61,43) x(1:61,1:61,44) x(1:61,1:61,45) x(1:61,1:61,46) x(1:61,1:61,47) x(1:61,1:61,48) x(1:61,1:61,49) x(1:61,1:61,50) ...
         x(1:61,1:61,51) x(1:61,1:61,52) x(1:61,1:61,53) x(1:61,1:61,54) x(1:61,1:61,55) x(1:61,1:61,56) x(1:61,1:61,57) x(1:61,1:61,58) x(1:61,1:61,59) x(1:61,1:61,60) ...
         x(1:61,1:61,61)];
     
xline=Xmat';
xline=xline(:)';
[N,xbin]=histc(xline,x_range);
Nnorm=N./trapz(x_range,N); % Nnorm is the modelable pdf

%comment 6/12:  Check that Nnorm variable is normalized by estimating its
% cumulative distribution
cumul=zeros(1,length(Nnorm));
for i=1:length(Nnorm)
    if i==1
    cumul(i)=Nnorm(i)*(x_range(2)-x_range(1));
    else
    cumul(i)=cumul(i-1)+Nnorm(i)*(x_range(2)-x_range(1));
    end
end



 %comment 7/12: measured parameter values from the article 
 fw_m=[7.76 6.66 6 7.44 6 7.72 3.46 6.08 6 5.77 4.94 4.56 5.51 6 6 4.96 6 6.41]*0.01;
b_m=[0.22 0.12 0.13 0.49 0.8 0.22 0.55 0.30 0.24 0.18 0.4 0.24 0.66 0.17 1.73 0.17 1.08 0.53]*0.01;
vr_m=[0.017 0.001 0.019 0.001 0.010 0.001 0.001 0.001 0.001 0.084 0.001 0.381 0.001 0.007 0.003 0.147 0.005 0.001];

 %comment 8/12: Estimation of the output from the estimated parameters 
for i =1:length(fw_m)
    x_m(i)=modelss_2(fw_m(i),vr_m(i),b_m(i));
end

% comment 9/12:  Unmodelled parameters (VH mutation status, CD38 expression, Age, Growth rate of WBC)
x_um=[0.069 0.071 0.05 0.051 0.003 0.069 0.024 0.003 0.037 0.01 0.02 0 0.003 0 0 0 0.003 0;
    0.01 0.21 0.02 0.05 0.04 0.01 0 0.06 0.01 0.57 0.02 0.24 0.32 0.72 0.05 0.68 0.98 0.09;
    60 76 64 40 58 63 65 50 71 46 74 71 60 55 63 49 63 67;
   6.0e-05,-0.00125,-0.00073,-1.0e-05,0.00656,0.00087,0.00654,0.00035,0.00033,0.00567,-0.00289,0.00302,-0.00311,0.00045,0.00712,0.00241,-0.01052,-0.00053];

% comment 10/12:  Calculate the pdf from the patient ensemble
DPYXu = [x_m; x_um(1,:); x_um(2,:);x_um(3,:); x_um(4,:)]';
NSiml=18;
bw1 = std(DPYXu(:,1)) .* (4 / (NSiml .* (size(DPYXu,2) + 2) ) ) .^ (1 / (size(DPYXu,2) + 4));
bw2 = std(DPYXu(:,2)) .* (4 / (NSiml .* (size(DPYXu,2) + 2) ) ) .^ (1 / (size(DPYXu,2) + 4));
bw3 = std(DPYXu(:,3)) .* (4 / (NSiml .* (size(DPYXu,2) + 2) ) ) .^ (1 / (size(DPYXu,2) + 4));
bw4 = std(DPYXu(:,4)) .* (4 / (NSiml .* (size(DPYXu,2) + 2) ) ) .^ (1 / (size(DPYXu,2) + 4));
bw5 = std(DPYXu(:,5)) .* (4 / (NSiml .* (size(DPYXu,2) + 2) ) ) .^ (1 / (size(DPYXu,2) + 4));

 [iwcoord] = ndgrid(x_range);

 % Put everything in the form of column vectors
    iwcoord = iwcoord(:);
     pts_iwtm = [iwcoord];
     
     
       for i = 1:NSiml % loop over the patients to build the unmodelable pdf structure

        % Concatenate the values of the i-th patient
        pts_iwtmn0v0 = [pts_iwtm, x_um(1,i) .* ones(size(pts_iwtm,1),1), x_um(2,i) .* ones(size(pts_iwtm,1),1),x_um(3,i) .* ones(size(pts_iwtm,1),1),x_um(4,i) .* ones(size(pts_iwtm,1),1)];

        % Use mvksdensity to obtain the probability for each patient over the clinical output space
        adist = mvksdensity(DPYXu, pts_iwtmn0v0, 'Bandwidth', [bw1 bw2 bw3 bw4 bw5]);

        % Normalize the distribution
        a{i} = adist ./ trapz(x_range, adist);
        
        clear pts_iwtmn0v0 adist adist_mat 
        
  
       end
       
       
       % comment 11/12:  Estimation of P(Y)=P(Y|Xm)*P(Y|Xu)
      for i = 1:18
        
        % Calculate the corrected probability distribution and normalize it
        pfin_temp = a{i} .* Nnorm';
        pfin{i} = pfin_temp ./ trapz(x_range,pfin_temp); % pfin is the BaM3 pdf
        
      end
    
      
      
   %% Post-processing of the results
   
   % Collect the model parameters from the patients' data
   pat_par=[	7.76E-02	0.017	2.20E-03	;
	6.66E-02	0.001	1.20E-03	;	
	6.00E-02	0.019	1.30E-03	;	
	7.44E-02	0.001	4.90E-03	;	
	6.00E-02	0.01	8.00E-03	;	
	7.72E-02	0.001	2.20E-03	;	
	3.46E-02	0.001	5.50E-03	;	
	6.08E-02	0.001	3.00E-03	;	
	6.00E-02	0.001	2.40E-03	;	
	5.77E-02	0.084	1.80E-03	;	
	4.94E-02	0.001	4.00E-03	;	
	4.56E-02	0.381	2.40E-03	;	
	5.51E-02	0.001	6.60E-03	;	
	6.00E-02	0.007	1.70E-03	;	
	6.00E-02	0.003	1.73E-02	;	
	4.96E-02	0.147	1.70E-03	;	
	6.00E-02	0.005	1.08E-02	;	
	6.41E-02	0.001	5.30E-03	]	;

	% Calculate the corresponding value for the clinical output (f_50)
for i =1:length(pat_par)
    f50_pat(i)=modelss_2(pat_par(i,1),pat_par(i,2),pat_par(i,3));
end

	% Calculate the expected value from the BaM3 pdf

for i =1:length(pat_par)
Bam3_ave(i)= trapz(x_range,x_range'.*pfin{i});
end

	% Calculate the variance from the BaM3 pdf
for i =1:length(pat_par)
Bam3_ave_2(i)= trapz(x_range,x_range.^2'.*pfin{i});
sigma_2(i)=Bam3_ave_2(i)-Bam3_ave(i).^2;
sigma(i)=sqrt(sigma_2(i));
end

	% Calculate the BaM3 method score for each patient

for i =1:length(pat_par)
   score(i)=((1-Bam3_ave(i)/f50_pat(i))^2)^0.5; 
end


%% Plot Fig 6B

% Create a cell array with the patients' names
patname = {'CLL107', 'CLL109', 'CLL165', 'CLL169', 'CLL189', 'CLL280', 'CLL282', 'CLL321', 'CLL331', 'CLL332', 'CLL336', 'CLL355', 'CLL360', 'CLL394', 'CLL400', 'CLL403', 'CLL408', 'CLL472'}';

% Assign the variables
x = [1:18]';
y_p = f50_pat;
y = Bam3_ave;
stdev = sigma;
lo = y - stdev;
hi = y + stdev;

% Generate the plot
figure,
hold on
errorbar(x,y,stdev,'.','DisplayName','BaM^3 method','MarkerSize',30,'Color',[0.00, 0.45, 0.74])
plot(x,y_p,'.','DisplayName','Messmer et al.','MarkerSize',30,'Color',[0.85, 0.33, 0.10])

xlabel('Patient')
ylabel('Fraction labeled at day 50')
set(gca,'XTick',x,'XTickLabel',patname,'xticklabelrotation',70)
legend('Location','NorthWest')

%axis square;
set(gca, 'FontSize', 18);


%% Plot Fig S9
colors = [ 0.93, 0.69, 0.13;    % yellow
           0.50, 0.50, 0.50;    % gray
           0.00, 0.45, 0.74];   % blue
figure, % part 1
for i = 1:9
    subplot(3,3,i)
    plot(x_range, Nnorm, 'LineWidth', 2, 'DisplayName', 'Model', 'Color', colors(3,:))
    hold on
    plot(x_range, a{i}, 'LineWidth', 2, 'DisplayName', 'Data', 'Color', colors(2,:))
    plot(x_range, pfin{i}, 'LineWidth', 2, 'DisplayName', 'BaM^3', 'Color', colors(1,:))
    if i == 1
        legend('Location','NorthEast')
    end
    xlabel('f_{50}')
    ylabel('Pdf')
    axis([0,0.6,0,12])
    set(gca, 'FontSize', 18);
    axis square
    title(sprintf('\\rm%s',patname{i}))
end

figure, % part 2
for i = 10:18
    subplot(3,3,i-9)
    plot(x_range, Nnorm, 'LineWidth', 2, 'DisplayName', 'Model', 'Color', colors(3,:))
    hold on
    plot(x_range, a{i}, 'LineWidth', 2, 'DisplayName', 'Data', 'Color', colors(2,:))
    plot(x_range, pfin{i}, 'LineWidth', 2, 'DisplayName', 'BaM^3', 'Color', colors(1,:))
    if i == 1
        legend('Location','NorthEast')
    end
    xlabel('f_{50}')
    ylabel('Pdf')
    axis([0,0.6,0,12])
    set(gca, 'FontSize', 18);
    axis square
    title(sprintf('\\rm%s',patname{i}))
end

%% Plot Fig S10

% Standardization of the parameters
fw_m_s = (fw_m - mean(fw_m))./std(fw_m);
b_m_s = (b_m - mean(b_m))./std(b_m);
vr_m_s = (vr_m - mean(vr_m))./std(vr_m);

figure,
hold on,
plot(x, fw_m_s, '.', 'MarkerSize', 30, 'DisplayName', 'f_w')
plot(x, b_m_s, '+', 'MarkerSize', 10, 'DisplayName', 'b')
plot(x, vr_m_s, 'o', 'MarkerSize', 10, 'DisplayName', 'v_r')

xlabel('Patient')
ylabel('Standardized parameters')
set(gca,'XTick',x,'XTickLabel',patname,'xticklabelrotation',70)
legend('Location','SouthEast')
axis([0,19,-4,4])
set(gca, 'FontSize', 18)
grid on
box on


