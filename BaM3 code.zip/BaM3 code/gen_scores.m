function gen_scores(Np)

% Generate the score metrics

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set the parameters for comparison
uncs = 'nv';   % Select the unmodelable case
fk_icond = 25; % Set the initial condition - t_0 (25: 2y; 13: 1y) 
thr = 0.05;    % Set the threshold for comparison
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

pval_vec = [0.01, 0.025, 0.05, 0.075, 0.1]; % Vector of alpha values 
tec_vec = [1, 3, 6, 9, 12]; % Vector of prediction times t_p

NSiml = Np; % number of patients

for itec = 1:length(tec_vec)
    for ialp = 1:length(pval_vec)
        
        fk_econd = tec_vec(itec); % set t_p

        tfl_pval = pval_vec(ialp); % tolerance to obtain the modelable pdf

        % Load the dataset
        load(strcat('./DTfiles_nv/fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), 'DT.mat'), 'tfl_ec', 'tms_ec');
        
        load(strcat('./MODELABLE_DISTS_nv/MODDIST_fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), '_pval', num2str(tfl_pval), '.mat'), 'tfl_range', 'tms_range', 'q');

        load(strcat('./UNMODELABLE_DISTS_', uncs, '/UNMODDIST_fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), '.mat'), 'a');
        
        load(strcat('./FINAL_DISTS_', uncs, '/FINDIS_fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), '_pval', num2str(tfl_pval), '.mat'), 'pfin');


        for i=1:NSiml

            % Calculate the expected values for the distributions
            IWq = trapz(tfl_range, tfl_range .* trapz(tms_range,q{i},2)'); % Expected IW for modelable pdf
            TMq = trapz(tms_range, tms_range .* trapz(tfl_range,q{i},1));  % Expected TS for modelable pdf

            IWpf = trapz(tfl_range, tfl_range .* trapz(tms_range,pfin{i},2)'); % Expected IW for BaM3 pdf
            TMpf = trapz(tms_range, tms_range .* trapz(tfl_range,pfin{i},1));  % Expected TS for BaM3 pdf

            % Evaluate the non dimensional error between the full model values and the ones obtained from the distributions
            Dq{ialp,itec}(i) = sqrt(1/2*((1 - TMq/tms_ec(1,i) )^2  + (1 - IWq/tfl_ec(1,i) )^2));
            Df{ialp,itec}(i) = sqrt(1/2*((1 - TMpf/tms_ec(1,i))^2  + (1 - IWpf/tfl_ec(1,i))^2));
            
            % Evaluate the partial errors
            DTMq{ialp,itec}(i) = sqrt( (1 - TMq/tms_ec(1,i)  )^2 );
            DTMf{ialp,itec}(i) = sqrt( (1 - TMpf/tms_ec(1,i) )^2 );
            DIWq{ialp,itec}(i) = sqrt( (1 - IWq/tfl_ec(1,i)  )^2 );
            DIWf{ialp,itec}(i) = sqrt( (1 - IWpf/tfl_ec(1,i) )^2 );
            
        end

        % Count the number of improved predictions
        ieq = find(abs(Df{ialp,itec}(:) - Dq{ialp,itec}(:)) <= thr * Dq{ialp,itec}(:)); % No change
        ide = find(Df{ialp,itec}(:) > (1 + thr) * Dq{ialp,itec}(:));    % Deterioration of prediction
        iim = find(Df{ialp,itec}(:) < (1 - thr) * Dq{ialp,itec}(:));    % Improvement of prediction

        % Calculate the scores
        Seq(ialp,itec) = length(ieq) / NSiml;
        Sde(ialp,itec) = length(ide) / NSiml;
        Sim(ialp,itec) = length(iim) / NSiml;
        
        % Save the indeces in a cell array
        Ieq{ialp,itec} = ieq;
        Ide{ialp,itec} = ide;
        Iim{ialp,itec} = iim;
    
        clear ieq ide iim IWq TMq IWpf TMpf
    end
end

% Save scores at fixed alpha
alp_fix = 0.05;
ialp = find(pval_vec == alp_fix);
Sim_vec = Sim(ialp, :);
Seq_vec = Seq(ialp, :);
Sde_vec = Sde(ialp, :);

for j=1:length(tec_vec) % Export the distances at fixed alpha
    Dqaf{1,j} = Dq{ialp,j}; 
    Dfaf{1,j} = Df{ialp,j};
end

% Save results
save(strcat('./scores_', uncs, '/Scores_thr', num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'Df', 'Dq', 'Seq', 'Sim', 'Sde', 'pval_vec', 'tec_vec');
save(strcat('./scores_', uncs, '/Scores_TMqfIWqf_thr', num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'DTMq', 'DTMf', 'DIWq', 'DIWf');
save(strcat('./scores_', uncs, '/PatientsId_thr', num2str(thr), '_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'Ieq', 'Ide', 'Iim');
save(strcat('./scores_', uncs, '/Scores_thr', num2str(thr), '_fki', num2str(fk_icond), 'fixalp', num2str(alp_fix), '_te', sprintf('%d_', tec_vec), '.mat'), 'Sim_vec', 'Seq_vec', 'Sde_vec', 'Dqaf', 'Dfaf');


%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set the parameters for comparison
uncs = 'nv';   % Select the unmodelable case
fk_icond = 13; % Set the initial condition - t_0 (25: 2y; 13: 1y) 
thr = 0.05;    % Set the threshold for comparison
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

pval_vec = [0.01, 0.025, 0.05, 0.075, 0.1]; % Vector of alpha values 
tec_vec = [1, 3, 6, 9, 12]; % Vector of prediction times t_p


for itec = 1:length(tec_vec)
    for ialp = 1:length(pval_vec)
        
        fk_econd = tec_vec(itec); % set t_p

        tfl_pval = pval_vec(ialp); % tolerance to obtain the modelable pdf

        % Load the dataset
        load(strcat('./DTfiles_nv/fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), 'DT.mat'), 'tfl_ec', 'tms_ec');
        
        load(strcat('./MODELABLE_DISTS_nv/MODDIST_fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), '_pval', num2str(tfl_pval), '.mat'), 'tfl_range', 'tms_range', 'q');

        load(strcat('./UNMODELABLE_DISTS_', uncs, '/UNMODDIST_fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), '.mat'), 'a');
        
        load(strcat('./FINAL_DISTS_', uncs, '/FINDIS_fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), '_pval', num2str(tfl_pval), '.mat'), 'pfin');


        for i=1:NSiml

            % Calculate the expected values for the distributions
            IWq = trapz(tfl_range, tfl_range .* trapz(tms_range,q{i},2)'); % Expected IW for modelable pdf
            TMq = trapz(tms_range, tms_range .* trapz(tfl_range,q{i},1));  % Expected TS for modelable pdf

            IWpf = trapz(tfl_range, tfl_range .* trapz(tms_range,pfin{i},2)'); % Expected IW for BaM3 pdf
            TMpf = trapz(tms_range, tms_range .* trapz(tfl_range,pfin{i},1));  % Expected TS for BaM3 pdf

            % Evaluate the non dimensional error between the full model values and the ones obtained from the distributions
            Dq{ialp,itec}(i) = sqrt(1/2*((1 - TMq/tms_ec(1,i) )^2  + (1 - IWq/tfl_ec(1,i) )^2));
            Df{ialp,itec}(i) = sqrt(1/2*((1 - TMpf/tms_ec(1,i))^2  + (1 - IWpf/tfl_ec(1,i))^2));
            
            % Partial errors
            DTMq{ialp,itec}(i) = sqrt( (1 - TMq/tms_ec(1,i)  )^2 );
            DTMf{ialp,itec}(i) = sqrt( (1 - TMpf/tms_ec(1,i) )^2 );
            DIWq{ialp,itec}(i) = sqrt( (1 - IWq/tfl_ec(1,i)  )^2 );
            DIWf{ialp,itec}(i) = sqrt( (1 - IWpf/tfl_ec(1,i) )^2 );
            
        end

        % Count the number of improved predictions
        ieq = find(abs(Df{ialp,itec}(:) - Dq{ialp,itec}(:)) <= thr * Dq{ialp,itec}(:)); % No change
        ide = find(Df{ialp,itec}(:) > (1 + thr) * Dq{ialp,itec}(:));    % Deterioration of prediction
        iim = find(Df{ialp,itec}(:) < (1 - thr) * Dq{ialp,itec}(:));    % Improvement of prediction

        % Calculate the scores
        Seq(ialp,itec) = length(ieq) / NSiml;
        Sde(ialp,itec) = length(ide) / NSiml;
        Sim(ialp,itec) = length(iim) / NSiml;
        
        % Save the indeces in a cell array
        Ieq{ialp,itec} = ieq;
        Ide{ialp,itec} = ide;
        Iim{ialp,itec} = iim;
    
        clear ieq ide iim IWq TMq IWpf TMpf
    end
end

% Save scores at fixed alpha
alp_fix = 0.05;
ialp = find(pval_vec == alp_fix);
Sim_vec = Sim(ialp, :);
Seq_vec = Seq(ialp, :);
Sde_vec = Sde(ialp, :);

for j=1:length(tec_vec) % Export the distances at fixed alpha
    Dqaf{1,j} = Dq{ialp,j}; 
    Dfaf{1,j} = Df{ialp,j};
end

% Save results
save(strcat('./scores_', uncs, '/Scores_thr', num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'Df', 'Dq', 'Seq', 'Sim', 'Sde', 'pval_vec', 'tec_vec');
save(strcat('./scores_', uncs, '/Scores_TMqfIWqf_thr', num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'DTMq', 'DTMf', 'DIWq', 'DIWf');
save(strcat('./scores_', uncs, '/PatientsId_thr', num2str(thr), '_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'Ieq', 'Ide', 'Iim');
save(strcat('./scores_', uncs, '/Scores_thr', num2str(thr), '_fki', num2str(fk_icond), 'fixalp', num2str(alp_fix), '_te', sprintf('%d_', tec_vec), '.mat'), 'Sim_vec', 'Seq_vec', 'Sde_vec', 'Dqaf', 'Dfaf');


end
