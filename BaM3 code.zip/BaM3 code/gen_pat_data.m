function gen_pat_data(Np)

N = Np; % Define the number of patients

%rng(10); % Fix the seed for rand (to make results reproducible)

% Set the max and min values of the parameters for the full model
Dmin = 0.0273000; Dmax = 0.2730000;
bmin = 0.00273000; bmax = 0.02730000;
h2min = 0.00573; h2max = 0.114;
g2min = 0.0000000000005; g2max = 0.000000000015;
g1min = 0.01; g1max = 0.25; 

% Generate the parameters for the full model from a uniform distribution
% Generate the list of motility D
D_list = Dmin + (Dmax-Dmin).*rand(1,N);

% Gen. list of proliferation b
b_list = bmin + (bmax-bmin).*rand(1,N);

% Gen. list of oxygen consumption h2
h2_list = h2min + (h2max-h2min).*rand(1,N);

% Gen. list of oxygen consumption g2
g2_list = g2min + (g2max-g2min).*rand(1,N);

% Gen. list of oxygen consumption g1
g1_list = g1min + (g1max-g1min).*rand(1,N);


% Save variables to files
Dfile = fopen('./CREATE_DATASET/Dlist.txt','w');
fprintf(Dfile,'%1.4e\t',D_list);
fclose(Dfile);

bfile = fopen('./CREATE_DATASET/blist.txt','w');
fprintf(bfile,'%1.4e\t',b_list);
fclose(bfile);

h2file = fopen('./CREATE_DATASET/h2list.txt','w');
fprintf(h2file,'%1.4e\t',h2_list);
fclose(h2file);

g2file = fopen('./CREATE_DATASET/g2list.txt','w');
fprintf(g2file,'%1.4e\t',g2_list);
fclose(g2file);

g1file = fopen('./CREATE_DATASET/g1list.txt','w');
fprintf(g1file,'%1.4e\t',g1_list);
fclose(g1file);

end