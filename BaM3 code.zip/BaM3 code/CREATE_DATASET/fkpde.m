function [] = fkpde(simul_id, ...
                    icond_ind)
                
%-------------------------------------------------------------------------%
%---------------------> Loading pdesys simulation <-----------------------%
%-------------------------------------------------------------------------%

    simul = load(strcat('DATASET/Simulations_pdesys/simulation_pdesys_', num2str(simul_id), '.mat'), ...
                        'c',  ...
                        'n',  ...
                        'v',  ...
                        'Dc', ...
                        'bc', ...
                        'as', ...
                        'bs', ...
                        'h2', ...
                        'g1', ...
                        'g2');

%-------------------------------------------------------------------------%
%--------------------------> Model Parameters <---------------------------%
%-------------------------------------------------------------------------%

    %=> Loading the initial condition
    rho0 = simul.c(icond_ind,:);
    
%-------------------------------------------------------------------------%
%------------------------> Simulation Parameters <------------------------%
%-------------------------------------------------------------------------%

    m     = 0;            %=> 1D problem
    th    = 30;           %=> (days) time discretization 
    Tf    = 3.60e+2;      %=> (days) Final time of the simulation
    L     = 300;          %=> (mm) length of the domain
    xh    = 2.5e-2;       %=> (mm) spatial discretization
    time  = 0:th:Tf;      %=> Time-steps at which the solutions are returned
    Xmesh = 0:xh:L;       %=> Discretized spatial domain

%-------------------------------------------------------------------------%
%--------------------------> Model Simulations <--------------------------%
%-------------------------------------------------------------------------%
    
    D_list = [0.0273000, 0.088725, 0.1501500, 0.2115750, 0.2730000];
    b_list = [0.00273000, 0.0088725, 0.01501500, 0.02115750, 0.02730000];
    
    for i=1:length(D_list)
        
        Dc = D_list(1,i);
    
        for j=1:length(b_list)

            bc = b_list(1,j);
            
            opt = odeset('RelTol', 1e-5, 'AbsTol', 1e-7);
            sol = pdepe(m, @pdecoef, @pdeic, @pdebc, Xmesh, time, opt);

            c_map{i,j} = sol;
        end
    end
    
%-------------------------------------------------------------------------%

    save(strcat('DATASET/Simulations_fkpde_', num2str(icond_ind), '/simulation_fkpde_', num2str(simul_id), '.mat'), ...
                'rho0',  ...
                'c_map');

%|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||%
%-----------------------> Coefficients for pdepe <------------------------%
%|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||%

    function [cFK, fFK, sFK] = pdecoef(xmesh, time, u, DuDx)
        
        cFK = 1;            %=> time-derivative term
        fFK = Dc.*DuDx;     %=> flux term
        sFK = bc.*u.*(1-u); %=> source term
    end

%|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||%
%-------------------------> Initial Condition <---------------------------%
%|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||%

    function u0 = pdeic(xmesh)
        
        %=> It looks like that, to pass the IC (which is defined over Xmesh), 
        %   it is necessary to interpolate it to the spatial discretization 
        %   (xmesh) that it is provided to pdeic
        
        u0 = interp1(Xmesh, rho0, xmesh);
    end

%|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||%
%-------------------------> Boundary Conditions <-------------------------%
%|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||%

    function [pl, ql, pr, qr] = pdebc(xl, ul, xr, ur, time)
        
        %=> We impose no-flux BCs,
        %   both for x = 0 and x = L.
        
        pl = 0;
        ql = 1;
        pr = 0;
        qr = 1;
    end

%-------------------------------------------------------------------------%
end