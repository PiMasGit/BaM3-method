function plot_dists(fki, fke, Np, idpat)

% Fig 3 A,B,C

close all;

% Load the dataset

NSiml = Np; % number of patients

% Select unmodelabe case
uncs = 'nv';
    
    % set t_0
    fk_icond = fki; 
    
    % set t_p
    fk_econd = fke; 

tfl_pval = 0.05; % tolerance to obtain the modelable pdf


load(strcat('./DTfiles_nv/fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), 'DT.mat'), 'tfl_ec', 'tms_ec');
load(strcat('./MODELABLE_DISTS_nv/MODDIST_fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), '_pval', num2str(tfl_pval), '.mat'), 'tfl_range', 'tms_range', 'q');
load(strcat('./UNMODELABLE_DISTS_', uncs, '/UNMODDIST_fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), '.mat'), 'a');    
load(strcat('./FINAL_DISTS_', uncs, '/FINDIS_fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), '_pval', num2str(tfl_pval), '.mat'), 'pfin');

%% Patient selection
if idpat == 0
    i = randi(NSiml, 1); % Selects a random patient
else 
    i = idpat;
end

% FontSize for the plots
fz = 24;


%% Find the expected values  
IWq = trapz(tfl_range, tfl_range .* trapz(tms_range,q{i},2)'); % Expected IW for modelable pdf
TMq = trapz(tms_range, tms_range .* trapz(tfl_range,q{i},1));  % Expected TS for modelable pdf

IWpf = trapz(tfl_range, tfl_range .* trapz(tms_range,pfin{i},2)'); % Expected IW for BaM3 pdf
TMpf = trapz(tms_range, tms_range .* trapz(tfl_range,pfin{i},1));  % Expected TS for BaM3 pdf

%% Find the mode
[maxq, ~] = max(q{i}(:));
[imIWq, imTMq] = find(q{i} == maxq);
mIWq = (tfl_range(imIWq));
mTMq = (tms_range(imTMq));

[maxpf, ~] = max(pfin{i}(:));
[imIWpf, imTMpf] = find(pfin{i} == maxpf);
mIWpf = (tfl_range(imIWpf));
mTMpf = (tms_range(imTMpf));


%% Visualize the modelable pdf
figure;
set(gca, 'FontSize', fz);

axis square;
hold on;
contourf(tms_range, tfl_range, q{i}(:,:));
colorbar;
scatter(tms_ec(1,i), tfl_ec(1,i), 'r', 'filled')
scatter(TMq, IWq, 'k', 'filled')
scatter(mTMq, mIWq, 'g', 'filled')
hold off;
xlabel('Tumor size [mm]');
ylabel('Infiltration width [mm]');
title(sprintf('\\rm model pdf, Patient ID = %d', i));


%% Visualize the unmodelable pdf
figure;
set(gca, 'FontSize', fz);

axis square;
hold on;
contourf(tms_range, tfl_range, a{i}(:,:));
colorbar;
hold off;
xlabel('Tumor size [mm]');
ylabel('Infiltration width [mm]');
title(sprintf('\\rm data pdf, Patient ID = %d', i));


%% Visualize the BaM3 pdf
figure;
set(gca, 'FontSize', fz);

axis square;
hold on;
contourf(tms_range, tfl_range, pfin{i}(:,:));
cpf = colorbar;
cpf.Ruler.Exponent = -3;
scatter(tms_ec(1,i), tfl_ec(1,i), 'r', 'filled')
scatter(TMpf, IWpf, 'k', 'filled')
scatter(mTMpf, mIWpf, 'g', 'filled')
hold off;
xlabel('Tumor size [mm]');
ylabel('Infiltration width [mm]');
title(sprintf('\\rm BaM3 pdf, Patient ID = %d', i));


%% Highlight difference btw math model and BaM3 pdfs
figure,
subplot(1,2,1);
set(gca, 'FontSize', fz);
axis square;
hold on;
contourf(tms_range, tfl_range, q{i}(:,:));
colorbar;
scatter(tms_ec(1,i), tfl_ec(1,i), 'r', 'filled')
scatter(TMq, IWq, 'k', 'filled')
scatter(mTMq, mIWq, 'g', 'filled')

line([tms_ec(1,i), TMq],[tfl_ec(1,i),IWq],'Color',[1,1,1],'LineWidth',2)
for k = 1:length(mTMq)
    line([tms_ec(1,i), mTMq(k)],[tfl_ec(1,i),mIWq(k)],'Color',[1,1,1],'LineStyle',':','LineWidth',2)
end

hold off;
xlabel('Tumor size [mm]', 'FontSize', 18);
ylabel('Infiltration width [mm]', 'FontSize', 18);
title(sprintf('q-dist from model - patient i = %d', i), 'FontSize', 18);
axis([tms_ec(1,i)-10, tms_ec(1,i)+10, tfl_ec(1,i)-10, tfl_ec(1,i)+10]);

subplot(1,2,2);
set(gca, 'FontSize', fz);
axis square;
hold on;
contourf(tms_range, tfl_range, pfin{i}(:,:));
cpfc = colorbar;
cpfc.Ruler.Exponent = -3;
scatter(tms_ec(1,i), tfl_ec(1,i), 'r', 'filled')
scatter(TMpf, IWpf, 'k', 'filled')
scatter(mTMpf, mIWpf, 'g', 'filled')

line([tms_ec(1,i), TMpf],[tfl_ec(1,i),IWpf],'Color',[1,1,1],'LineWidth',2)
for k = 1:length(mTMpf)
    line([tms_ec(1,i), mTMpf(k)],[tfl_ec(1,i),mIWpf(k)],'Color',[1,1,1],'LineStyle',':','LineWidth',2)
end

hold off;
xlabel('Tumor mass [mm]', 'FontSize', 18);
ylabel('Infiltration width [mm]', 'FontSize', 18);
title(sprintf('\\rm pfin-dist from model - patient i = %d', i), 'FontSize', 18);
axis([tms_ec(1,i)-10, tms_ec(1,i)+10, tfl_ec(1,i)-10, tfl_ec(1,i)+10]);

end