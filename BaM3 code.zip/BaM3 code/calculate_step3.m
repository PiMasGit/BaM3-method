function calculate_step3(fki, fke, Np)

    
    %---------------------------------------------------------------------%
    %#####################################################################%
    %---------------------------------------------------------------------%    
    
    NSiml = Np;
    
    % set t_0
    fk_icond = fki;  
    % set t_p
    fk_econd = fke; 

    alpha_vec = [0.01, 0.025, 0.05, 0.075, 0.1]; % alpha values 
    
 for ialp = 1:length(alpha_vec)   % Loop over alpha values
            
    alpha = alpha_vec(ialp);
    
    %---------------------------------------------------------------------%
    %#####################################################################%
    %---------------------------------------------------------------------%

       
    %---------------------------------------------------------------------%
    % STEP 1
    %---------------------------------------------------------------------%
    
    %%% Load the distributions generated from the model
    load(strcat('MODELABLE_DISTS_nv/MODDIST_fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), '_pval', num2str(alpha), '.mat'), 'tfl_range', 'tms_range', 'q');    
    
    %---------------------------------------------------------------------%
    % STEP 2
    %---------------------------------------------------------------------%
    
    %%% Load the distributions generated from the unmodelables
    load(strcat('UNMODELABLE_DISTS_nv/UNMODDIST_fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), '.mat'), 'a'); 


    %---------------------------------------------------------------------%
    % STEP 3
    %---------------------------------------------------------------------%
    
    for i = 1:NSiml
        
        % Calculate the corrected probability distribution and normalize it
        pfin_temp = a{i} .* q{i};
        pfin{i} = pfin_temp ./ trapz(tfl_range,trapz(tms_range,pfin_temp,2));
        
    end
    
    %%% Save the final prob dists
    save(strcat('FINAL_DISTS_nv/FINDIS_fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), '_pval', num2str(alpha), '.mat'), 'pfin'); 
    
    clear a q pfin pfin_temp
 end  % End alpha loop 
    
    
end