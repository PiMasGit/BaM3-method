%% Read parameters from the txt files
cd './CREATE_DATASET/'

load Dlist.txt
load blist.txt
load h2list.txt
load g2list.txt
load g1list.txt

%% Simulate the full model
for i=1:N 
    pdesys(Dlist(i), blist(i), h2list(i), g1list(i), g2list(i), i);
end


%% Simulate the FK model
% => set t_0 = 12 months
a=13;

for i=1:N
    fkpde(i, a);
end

% => set t_0 = 24 months
a=25;

for i=1:N
    fkpde(i, a);
end

cd '..'