function plot_scores()

% Settings
fz = 24; % Select the font size for the figures
uncs = 'nv';   % Select the unmodelable case
colors = [ 0.93, 0.69, 0.13;    % yellow
           0.85, 0.33, 0.10;    % orange
           0.00, 0.45, 0.74];   % blue

thr = 0.05;    % Set the threshold for comparison
alp_fix = 0.05; % Select the alpha level


tec_vec = [1, 3, 6, 9, 12]; % Vector of prediction times t_p
fki_vec = [13, 25]; % Vector of clinical presentation times t_0


% Fig 3 F,I; Fig S4

for i = 1:length(fki_vec)
    
    fk_icond = fki_vec(i);
    load(strcat('./scores_', uncs, '/Scores_thr', num2str(thr), '_fki', num2str(fk_icond), 'fixalp', num2str(alp_fix), '_te', sprintf('%d_', tec_vec), '.mat'), 'Sim_vec', 'Seq_vec', 'Sde_vec', 'Dqaf', 'Dfaf');
    load(strcat('./scores_', uncs, '/ScoresM_thr', num2str(thr), '_fki', num2str(fk_icond), 'fixalp', num2str(alp_fix), '_te', sprintf('%d_', tec_vec), '.mat'), 'Smim_vec', 'Smeq_vec', 'Smde_vec', 'Dmqaf', 'Dmfaf');

    % Plot with stacked bars
    Si = Sim_vec;
    Se = Seq_vec;
    Sd = Sde_vec;
    Dq_a = Dqaf;
    Df_a = Dfaf;

    % Plot with stacked bars - mode
    Smi = Smim_vec;
    Sme = Smeq_vec;
    Smd = Smde_vec;
    Dmq_a = Dmqaf;
    Dmf_a = Dmfaf;    

    Ms = [Se', Sd', Si'];
    MsM = [Sme', Smd', Smi'];
    
    % Plot bar graph - exp value
    figure('Name',sprintf('t_0=%d months', fk_icond-1)) 
    hb = bar(Ms);

    for i = 1:length(hb)
        hb(i).FaceColor = colors(i,:);
    end

    set(gca, 'FontSize', fz);
    set(gca,'XtickLabel', cellstr(num2str(tec_vec')))
    axis square,
    axis([0.5, 5.5, 0, 1])
    xlabel('Time of prediction [months]');
    ylabel('Scores');
    title('\rm Prediction scores (exp value)');
    legend({'$S_u$', '$S_d$', '$S_i$'},'Location','NorthWest', 'Interpreter', 'Latex');
    
    
    % Plot bar graph - mode
    figure('Name',sprintf('t_0=%d months', fk_icond-1))
    hb = bar(MsM);

    for i = 1:length(hb)
        hb(i).FaceColor = colors(i,:);
    end

    set(gca, 'FontSize', fz);
    set(gca,'XtickLabel', cellstr(num2str(tec_vec')))
    axis square,
    axis([0.5, 5.5, 0, 1])
    xlabel('Time of prediction [months]');
    ylabel('Scores');
    title('\rm Prediction scores (mode)');
    legend({'$S_u$', '$S_d$', '$S_i$'},'Location','NorthWest', 'Interpreter', 'Latex');
end


% Fig 3 D,G

for i = 1:length(fki_vec)
    
    fk_icond = fki_vec(i);

    load(strcat('./scores_', uncs, '/Scores_thr', num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'Df', 'Dq', 'Seq', 'Sim', 'Sde', 'pval_vec', 'tec_vec');
    load(strcat('./scores_', uncs, '/Scores_TMqfIWqf_thr', num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'DTMq', 'DTMf', 'DIWq', 'DIWf');


    ialp = find(pval_vec == alp_fix);
    figure('Name', sprintf('t_0 = %d [months]', fk_icond-1)),
    hold on

    % Assemble the sample and label vectors for the violin plots
    samples = [Dq{ialp,1}, Df{ialp,1}];
    groups = [1 * ones(1, length(Dq{ialp,1})), 2 * ones(1, length(Dq{ialp,1}))];
    colors = [[0.85,0.33,0.1]; [0,0.45,0.74]]; % blue -> BaM3, orange -> FK

    for itec = 2:length(tec_vec)
        % Concatenate the samples, groups and colors variables to build the
        % plots on the same axis
        samples = [samples, Dq{ialp,itec}, Df{ialp,itec}];
        groups = [groups, (2*itec-1) * ones(1, length(Dq{ialp,itec})), (2*itec) * ones(1, length(Dq{ialp,itec}))];
        colors = [colors; [0.85,0.33,0.1]; [0,0.45,0.74]];
    end
        positions = 1:2*length(tec_vec);  % Set how many plots combined we want to show
        hvox=violinplot(samples, groups); % Plot the violin plots

        set(gca,'Xtick', positions(1:2:end)+0.5); 
        set(gca,'XtickLabel',cellstr(num2str(tec_vec')),'Fontsize',fz); 
        set(gca,'box','on');

        for j=1:length(hvox) 
            hvox(1,j).ViolinColor = colors(j,:); 
            hvox(1,j).EdgeColor = colors(j,:);
            hvox(1,j).ShowData = false;
        end

        LDq = hvox(1,1).ViolinPlot;
        LDf = hvox(1,2).ViolinPlot;

        legend([LDq, LDf], {'$d_m$','$d_b$'},'Location', 'NorthWest','Interpreter','latex');

        xlabel('Time of prediction [months]');
        ylabel('Error wrt full model');
        axis([0, positions(end)+1, 0, 1.1*max(samples)]);
        axis square
        
end


% Fig 3 E,H

for i = 1:length(fki_vec)
    
    fk_icond = fki_vec(i);

    % Violin plots for a given alpha - log of det(Sigma)
    load(strcat('./scores_', uncs, '/ScoresS_thr', num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'Sfdet', 'Sqdet');

    ialp = find(pval_vec == alp_fix);
    figure('Name', sprintf('t_0 = %d [months]', fk_icond-1)),
    hold on

    % Assemble the sample and label vectors for the violin plots
    samples = [log(Sqdet{ialp,1}), log(Sfdet{ialp,1})];
    groups = [1 * ones(1, length(Sqdet{ialp,1})), 2 * ones(1, length(Sqdet{ialp,1}))];
    colors = [[0.85,0.33,0.1]; [0,0.45,0.74]]; % blue -> BaM3, orange -> FK

    for itec = 2:length(tec_vec)
    % Concatenate the samples, groups and colors variables to build the
    % plots on the same axis
    samples = [samples, log(Sqdet{ialp,itec}), log(Sfdet{ialp,itec})];
    groups = [groups, (2*itec-1) * ones(1, length(Sqdet{ialp,itec})), (2*itec) * ones(1, length(Sqdet{ialp,itec}))];
    colors = [colors; [0.85,0.33,0.1]; [0,0.45,0.74]];
    end
    positions = 1:2*length(tec_vec);  % Set how many plots combined we want to show
    hvox=violinplot(samples, groups); % Plot the violin plots

    set(gca,'Xtick', positions(1:2:end)+0.5); 
    set(gca,'XtickLabel',cellstr(num2str(tec_vec')),'Fontsize',fz); 
    set(gca,'box','on');

    for j=1:length(hvox) 
        hvox(1,j).ViolinColor = colors(j,:); 
        hvox(1,j).EdgeColor = colors(j,:);
        hvox(1,j).ShowData = false;
    end

    LDq = hvox(1,1).ViolinPlot;
    LDf = hvox(1,2).ViolinPlot;

    legend([LDq, LDf], {'$s_m$','$s_b$'},'Location', 'NorthWest','Interpreter','latex');

    xlabel('Time of prediction [months]');
    ylabel('Effective variance of predictions');
    axis([0, positions(end)+1, 1.1*min(samples), 1.1*max(samples)]);
    axis square

end
