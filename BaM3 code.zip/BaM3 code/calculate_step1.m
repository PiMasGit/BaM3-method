function calculate_step1(fki, fke,Np)

    
    %---------------------------------------------------------------------%
    %#####################################################################%
    %---------------------------------------------------------------------%
    
    NSiml = Np;
    
    % initial condition of the Fisher-Kolmogorov simulation (t_0)
    fk_icond = fki; 
    % number of months from the initial condition (t_p)
    fk_econd = fke;

    alpha_vec = [0.01, 0.025, 0.05, 0.075, 0.1]; % alpha values
        
 for ialp = 1:length(alpha_vec)   % Loop over alpha values
            
    alpha = alpha_vec(ialp);
    
    %---------------------------------------------------------------------%
    %#####################################################################%
    %---------------------------------------------------------------------%
    %%% Load the dataset
    load(strcat('DTfiles_nv/fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), 'DT.mat'), 'tfl_ec', 'tms_ec', 'tfl_mec', 'tms_mec', 'tfl_mec_interp', 'tms_mec_interp', 'tfl_icond', 'tms_icond', 'nms_icond', 'vms_icond');
       
    %---------------------------------------------------------------------%
    % STEP 1
    %---------------------------------------------------------------------%
    
    tfl_pval = alpha; % set the alpha parameter
    tms_pval = alpha;
    
    mintlf = min(min(tfl_ec), min(tfl_icond));
    maxtlf = max(max(tfl_ec), max(tfl_icond));
    
    mintms = min(min(tms_ec), min(tms_icond));
    maxtms = max(max(tms_ec), max(tms_icond));
    
    tfl_range = mintlf:((maxtlf - mintlf) / 200):maxtlf; % Create the range of values for building the distributions
    tms_range = mintms:((maxtms - mintms) / 200):maxtms;
    
    %---------------------------------------------------------------------%
    
    for i = 1:NSiml
        
        tfl_Mx = tfl_mec_interp{1,i};
        tms_Mx = tms_mec_interp{1,i};
        
        %%% Calculate the multivariate distribution
        for l=1:length(tfl_range)
            for w=1:length(tms_range)
                q_inds = find(tfl_Mx >= ((1 - tfl_pval) * tfl_range(1,l)) & tfl_Mx <= ((1 + tfl_pval) * tfl_range(1,l))...
                            & tms_Mx >= ((1 - tms_pval) * tms_range(1,w)) & tms_Mx <= ((1 + tms_pval) * tms_range(1,w)));
                q{i}(l,w) =  length(q_inds) / (size(tfl_Mx,1) * size(tfl_Mx,2));
            end
        end
        
        % Normalize the modelable pdf for the single patient
        q{i} = q{i} ./ trapz(tfl_range,trapz(tms_range,q{i},2));
        
    end
    
    %%% Save the distributions generated from the model
    save(strcat('MODELABLE_DISTS_nv/MODDIST_fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), '_pval', num2str(tfl_pval), '.mat'), 'tfl_range', 'tms_range', 'q');        
    
    
    clear q
 end  % End alpha loop 
    
    
end