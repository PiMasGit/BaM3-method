function [x] = modelss_1(fw, vr,b)





t=[0:1:250];



for i=1:251
if(t(i)>84)
f(i)=(2*exp(5*fw+b*t(i)+(b*t(i))/vr)*b^2*(-1+vr)+exp(84*fw+b*t(i)+(b*t(i))/vr)*b^2*(-1+vr)-3*exp((b*t(i)*(1+vr))/vr)*b^2*(-1+vr)+3*exp((b+fw)*t(i))*(b-fw)*fw*vr^2-2*exp(b*t(i)+fw*t(i)+(5*b)/vr)*(b-fw)*fw*vr^2-exp(b*t(i)+fw*t(i)+(84*b)/vr)*(b-fw)*fw*vr^2+2*exp(5*b+fw*t(i)+(b*t(i))/vr)*fw*(b-fw*vr)+exp(84*b+fw*t(i)+(b*t(i))/vr)*fw*(b-fw*vr)+3*exp(t(i)*(fw+b/vr))*fw*(-b+fw*vr))/(exp(t(i)*(b+fw+b/vr))*(b-fw)*(-1+vr)*(b-fw*vr));
else
if(t(i)>5)
f(i)=(-3*exp(5*b-fw*t(i)+(b*t(i))/vr)*b^2*(-1+vr)+2*exp(5*b+5*fw-fw*t(i)+(b*t(i))/vr)*b^2*(-1+vr)+3*exp(5*b)*(b-fw)*fw*vr^2-2*exp((5*b*(1+vr))/vr)*(b-fw)*fw*vr^2+exp(b*(5+t(i)/vr))*(b-fw)*(-1+vr)*(b-fw*vr)+3*exp(b*(5+t(i)*(-1+vr^(-1))))*fw*(-b+fw*vr)-2*exp(b*(10+t(i)*(-1+vr^(-1))))*fw*(-b+fw*vr))/(exp((b*(t(i)+5*vr))/vr)*(b-fw)*(-1+vr)*(b-fw*vr));
else
f(i)=(3*(-(exp((b*t(i))/vr)*b^2*(-1+vr))-exp(fw*t(i))*fw*(-b+fw)*vr^2+exp(t(i)*(fw+b*(-1+vr^(-1))))*fw*(-b+fw*vr)+exp(t(i)*(fw+b/vr))*(-b+fw)*(-1+vr)*(-b+fw*vr)))/(exp(t(i)*(fw+b/vr))*(b-fw)*(-1+vr)*(b-fw*vr));
end
end
end
x=f(51);

%save(strcat('DATA/simulation_', num2str(simul_id), '.mat'), ... 
 %               'f','fw','b','vr');