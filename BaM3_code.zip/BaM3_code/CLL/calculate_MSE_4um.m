function [MSE, Bam3_ave, a_exp] = calculate_MSE_4um(unmod_mat, idx, export)

load('model_quantities.mat', 'Nnorm', 'x_m', 'fw_m', 'b_m', 'vr_m', 'x_range');

for icomb = 1:size(idx,1)
x_um = [unmod_mat(idx(icomb,1), :); ...
        unmod_mat(idx(icomb,2), :); ...
        unmod_mat(idx(icomb,3), :); ...
        unmod_mat(idx(icomb,4), :)];


% comment 10/12:  The material from line 90 of the m file to line to line 119
% is obtained mostly from your calculations
DPYXu = [x_m; x_um(1,:); x_um(2,:); x_um(3,:); x_um(4,:)]';

NSiml=17;

bw1 = std(DPYXu(:,1)) .* (4 / (NSiml .* (size(DPYXu,2) + 2) ) ) .^ (1 / (size(DPYXu,2) + 4));
bw2 = std(DPYXu(:,2)) .* (4 / (NSiml .* (size(DPYXu,2) + 2) ) ) .^ (1 / (size(DPYXu,2) + 4));
bw3 = std(DPYXu(:,3)) .* (4 / (NSiml .* (size(DPYXu,2) + 2) ) ) .^ (1 / (size(DPYXu,2) + 4));
bw4 = std(DPYXu(:,4)) .* (4 / (NSiml .* (size(DPYXu,2) + 2) ) ) .^ (1 / (size(DPYXu,2) + 4));
bw5 = std(DPYXu(:,5)) .* (4 / (NSiml .* (size(DPYXu,2) + 2) ) ) .^ (1 / (size(DPYXu,2) + 4));

 [iwcoord] = ndgrid(x_range);

 % Put everything in the form of column vectors
    iwcoord = iwcoord(:);
     pts_iwtm = iwcoord;
     
     
       for i = 1:NSiml % loop over the patients to build the a-dist structure

        % Concatenate the values of the i-th patient (NOTE: here the Xu are at time t0 !)
        pts_iwtmn0v0 = [pts_iwtm, x_um(1,i) .* ones(size(pts_iwtm,1),1), x_um(2,i) .* ones(size(pts_iwtm,1),1), x_um(3,i) .* ones(size(pts_iwtm,1),1), x_um(4,i) .* ones(size(pts_iwtm,1),1) ...
                                                                                                                                                       ];

        % Use mvksdensity to obtain the probability for each patient over the tm and iw range
        adist = mvksdensity(DPYXu, pts_iwtmn0v0, 'Bandwidth', [bw1 bw2 bw3 bw4 bw5 ...
                                                                           ]);

        % Normalize the distribution
        a{i} = adist ./ trapz(x_range, adist);
        
        clear pts_iwtmn0v0 adist adist_mat 
        
  
       end
       
       
       % comment 11/12:  Estimation of P(Y)=P(Y|Xm)*P(Y|Xu)
      for i = 1:NSiml
        
        % Calculate the corrected probability distribution and normalize it
        pfin_temp = a{i} .* Nnorm';
        pfin{i} = pfin_temp ./ trapz(x_range,pfin_temp);
        
      end
      
      
      for i =1:NSiml
Bam3_ave(i)= trapz(x_range,x_range'.*pfin{i});
end

for i =1:NSiml
Bam3_ave_2(i)= trapz(x_range,x_range.^2'.*pfin{i});
sigma_2(i)=Bam3_ave_2(i)-Bam3_ave(i).^2;
sigma(i)=sqrt(sigma_2(i));
end


MSE(icomb,1) = 1/NSiml * sum( (x_m - Bam3_ave).^2 );


%fprintf('\n\nMSE = %.10f\n', MSE(icomb,1))
a_exp = a{5};

if export == 1
    save('pdfs.mat', 'a', 'pfin');
end

end

end