%-------------------------------------------------------------------------%
%  Application of the BaM3 method to a dataset of CLL patients            %
%                                                                         %
%  Symeon Savvopoulos                                                     %
%  Pietro Mascheroni                                                      %
%                                                                         %
%  E-Mail: symeon.savvopoulos@kuleuven.be,                                %
%          pietro.mascheroni@helmholtz-hzi.de                             %
%                                                                         %  
%  Requires mvksdensity.m from the 'Statistics and Machine Learning       %
%  Toolbox'                                                               %  
%                                                                         %  
%  We use data from the following study:                                  %
%  Messmer, Bradley T., et al. "In vivo measurements document the dynamic %
%  cellular kinetics of chronic lymphocytic leukemia B cells."            %
%  The Journal of clinical investigation 115.3 (2005): 755-764.           %
%-------------------------------------------------------------------------%

clear
close all

saved = 1; % Select if the results from the mathematical model are already available in the path or not

% Find min and max values of the parameters

fw_min=3.46e-2;
fw_max=7.76e-2;


b_min=0.12e-2;
b_max=1.73e-2;

vr_min=0.001;
vr_max=0.381;


% Define the ranges of the parameters between min and max values

fw_range=[fw_min:((fw_max - fw_min) / 60):fw_max];
vr_range=[vr_min:((vr_max - vr_min) / 60):vr_max];
b_range=[b_min:((b_max - b_min) / 60):b_max];


% Unmodelables : [CD38 expression; Age; Growth rate of WBC; VH mutation status]
unmod_mat=[ 
            0.01 0.21 0.02 0.05 0.04 0 0.06 0.01 0.57 0.02 0.24 0.32 0.72 0.05 0.68 0.98 0.09; ...       
            60 76 64 40 58 65 50 71 46 74 71 60 55 63 49 63 67; ...
            6e-05, -1.25e-3, -7.3e-4, -1e-5, 6.56e-3, 6.54e-3, 3.5e-4, 3.3e-4, 5.67e-3, -2.89e-3, 3.02e-3, -3.11e-3, 4.5e-4, 7.12e-3, 2.41e-3, -1.052e-2, -5.3e-4; ...            
            0.069 0.071 0.05 0.051 0.003 0.024 0.003 0.037 0.01 0.02 0 0.003 0 0 0 0.003 0
            ];



% Create all combinations in the values of the parameters by running the
% mathematical model

if saved == 0

    x=zeros(61,61,61);

    for i =1:61
        for j=1:61
         for k=1:61
        x(i,j,k)=modelss_1(fw_range(i),vr_range(j),b_range(k));
        end
        end
    end


    % Find min and max values of the output and then discretixation
    % of the output in 300 bins
    xmin=min(min(min(x(:,:))));
    xmax=max(max(max(x(:,:))));
    x_range = xmin:((xmax - xmin) / 300):xmax;


    % Convert the 3D cell of x variable to 2D matrix
         Xmat=[x(1:61,1:61,1) x(1:61,1:61,2) x(1:61,1:61,3) x(1:61,1:61,4) x(1:61,1:61,5) x(1:61,1:61,6) x(1:61,1:61,7) x(1:61,1:61,8) x(1:61,1:61,9) x(1:61,1:61,10) ...
             x(1:61,1:61,11) x(1:61,1:61,12) x(1:61,1:61,13) x(1:61,1:61,14) x(1:61,1:61,15) x(1:61,1:61,16) x(1:61,1:61,17) x(1:61,1:61,18) x(1:61,1:61,19) x(1:61,1:61,20) ...
             x(1:61,1:61,21) x(1:61,1:61,22) x(1:61,1:61,23) x(1:61,1:61,24) x(1:61,1:61,25) x(1:61,1:61,26) x(1:61,1:61,27) x(1:61,1:61,28) x(1:61,1:61,29) x(1:61,1:61,30)...
             x(1:61,1:61,31) x(1:61,1:61,32) x(1:61,1:61,33) x(1:61,1:61,34) x(1:61,1:61,35) x(1:61,1:61,36) x(1:61,1:61,37) x(1:61,1:61,38) x(1:61,1:61,39) x(1:61,1:61,40) ...
             x(1:61,1:61,41) x(1:61,1:61,42) x(1:61,1:61,43) x(1:61,1:61,44) x(1:61,1:61,45) x(1:61,1:61,46) x(1:61,1:61,47) x(1:61,1:61,48) x(1:61,1:61,49) x(1:61,1:61,50) ...
             x(1:61,1:61,51) x(1:61,1:61,52) x(1:61,1:61,53) x(1:61,1:61,54) x(1:61,1:61,55) x(1:61,1:61,56) x(1:61,1:61,57) x(1:61,1:61,58) x(1:61,1:61,59) x(1:61,1:61,60) ...
             x(1:61,1:61,61)];

    xline=Xmat';
    xline=xline(:)';
    [N,xbin]=histc(xline,x_range);
    Nnorm=N./trapz(x_range,N);

    % Check that Nnorm variable is normalized by estimating its cumulative
    % probability distribution
    cumul=zeros(1,length(Nnorm));
    for i=1:length(Nnorm)
        if i==1
        cumul(i)=Nnorm(i)*(x_range(2)-x_range(1));
        else
        cumul(i)=cumul(i-1)+Nnorm(i)*(x_range(2)-x_range(1));
        end
    end

    % Measured parameter values from the article 
    fw_m=[7.76 6.66 6 7.44 6 3.46 6.08 6 5.77 4.94 4.56 5.51 6 6 4.96 6 6.41]*0.01;
    vr_m=[0.017 0.001 0.019 0.001 0.010 0.001 0.001 0.001 0.084 0.001 0.381 0.001 0.007 0.003 0.147 0.005 0.001];
    b_m=[0.22 0.12 0.13 0.49 0.8 0.55 0.30 0.24 0.18 0.4 0.24 0.66 0.17 1.73 0.17 1.08 0.53]*0.01;
    
    % Estimation of the output from the estimated parameters 
    for i =1:length(fw_m)
        x_m(i)=modelss_2(fw_m(i),vr_m(i),b_m(i));
    end
    
    save('model_quantities.mat', 'Nnorm', 'x_m', 'fw_m', 'b_m', 'vr_m', 'x_range');
else
    load('model_quantities.mat', 'Nnorm', 'x_m', 'fw_m', 'b_m', 'vr_m', 'x_range');
end


% Calculate MSE for 1 unmodelable
idx = nchoosek([1 2 3 4], 1);
[MSE_1] = calculate_MSE_1um(unmod_mat, idx); 

% Calculate MSE for 2 unmodelables
idx = nchoosek([1 2 3 4], 2);  
MSE_2 = calculate_MSE_2um(unmod_mat, idx); 

% Calculate MSE for 3 unmodelables
idx = nchoosek([1 2 3 4], 3);    
MSE_3 = calculate_MSE_3um(unmod_mat, idx); 

% Calculate MSE for 4 unmodelables
idx = nchoosek([1 2 3 4], 4);    
MSE_4 = calculate_MSE_4um(unmod_mat, idx, 0);      

% Calculate MSE for adding the unmodelables in the most straigthforward
% order (i.e. 1 2 3 4)
[MSE_fig(1,1), pred1um, a_5_1um]  = calculate_MSE_1um(unmod_mat, 1);
[MSE_fig(2,1), pred2um, a_5_2um] = calculate_MSE_2um(unmod_mat, [1 2]);
[MSE_fig(3,1), pred3um, a_5_3um] = calculate_MSE_3um(unmod_mat, [1 2 3]);
[MSE_fig(4,1), pred4um, a_5_4um] = calculate_MSE_4um(unmod_mat, [1 2 3 4], 1);

%% Plot the MSE for the different combinations of unmodelables (Figure 6A)
hi = [max(MSE_1); max(MSE_2); max(MSE_3); max(MSE_4)];
lo = [min(MSE_1); min(MSE_2); min(MSE_3); min(MSE_4)];

x = [1;2;3;4];
y = MSE_fig;
figure
hpa = patch([x; x(end:-1:1); x(1)], [lo; hi(end:-1:1); lo(1)], 'k');
hold on;
set(hpa, 'Facecolor', [0,0.45,0.74], 'Edgecolor', 'none', 'FaceAlpha', '0.15');
set(get(get(hpa,'Annotation'),'LegendInformation'),'IconDisplayStyle','off'); 
hpl = plot(x, y, 'LineWidth', 2, 'Color', [0,0.45,0.74]);
hold off;
box on
xlabel('# Unmodelables')
ylabel('MSE')
set(gca, 'FontSize', 18, 'XTick', [1 2 3 4]);

%% Plot real vs predicted values (Figure 6A)
figure
hold on
scatter(x_m, pred1um, 'filled', 'DisplayName', '1um')
scatter(x_m, pred2um, 'filled', 'DisplayName', '2um')
scatter(x_m, pred3um, 'filled', 'DisplayName', '3um')
scatter(x_m, pred4um, 'filled', 'DisplayName', '4um')
legend('Location','NorthEast')
plot(linspace(0,0.6,100), linspace(0,0.6,100), '--', 'Color', [0.5 0.5 0.5])
xlabel('Real f_{50}')
ylabel('Predicted f_{50}')
axis square
box on
set(gca, 'FontSize', 18)

%% Plot the unmodelables for a specific patient (CLL189, #5) (Figure 6B)
figure
hold on
plot(x_range, a_5_1um, 'LineWidth', 2, 'DisplayName', '1um')
plot(x_range, a_5_2um, 'LineWidth', 2, 'DisplayName', '2um')
plot(x_range, a_5_3um, 'LineWidth', 2, 'DisplayName', '3um')
plot(x_range, a_5_4um, 'LineWidth', 2, 'DisplayName', '4um')
legend('Location','NorthEast')
line([x_m(5),x_m(5)],[0, 5], 'LineStyle', '--', 'Color', 'red','LineWidth',2)
xlabel('$f_{50}$', 'Interpreter', 'Latex')
ylabel('$p(\mathbf{Y}=\hat{\mathbf{y}}|\mathbf{X}_u=\mathbf{x}^*_u)$','Interpreter','Latex')
set(gca, 'FontSize', 18)
axis square
box on

%% Plot all pdfs for the 4 unmodelables case (Figure S10)
load pdfs.mat

figure
for i=1:17
    subplot(4,5,i)
    hold on
    plot(x_range, Nnorm,'-', 'LineWidth', 2)
    plot(x_range, a{i},'-', 'LineWidth', 2)
    plot(x_range, pfin{i},'-', 'LineWidth', 2)
    if i==1 % plot the legend only for the first subplot
        legend('Model','Data','BaM^3')
        legend('Location','NorthWest')
    end
    %line([x_m(i),x_m(i)],[0,12],'Color','red','LineWidth',2,'LineStyle','--')
    xlabel('f_{50}')
    ylabel('Pdfs')
    title(sprintf('Patient %d', i))
    box on
    set(gca, 'FontSize', 18);
    axis([0,0.6,0,12])
end


%% Plot distribution of parameters (Figure S11)
% Create a cell array with the patients' names
patname = {'CLL107', 'CLL109', 'CLL165', 'CLL169', 'CLL189', 'CLL282', 'CLL321', 'CLL331', 'CLL332', 'CLL336', 'CLL355', 'CLL360', 'CLL394', 'CLL400', 'CLL403', 'CLL408', 'CLL472'}';

% Assign the variables
x = [1:17]';

% Standardization of the parameters
fw_m_s = (fw_m - mean(fw_m))./std(fw_m);
b_m_s = (b_m - mean(b_m))./std(b_m);
vr_m_s = (vr_m - mean(vr_m))./std(vr_m);

figure,
hold on,
plot(x, fw_m_s, '.', 'MarkerSize', 30, 'DisplayName', 'f_w')
plot(x, b_m_s, '+', 'MarkerSize', 10, 'DisplayName', 'b')
plot(x, vr_m_s, 'o', 'MarkerSize', 10, 'DisplayName', 'v_r')

xlabel('Patient')
ylabel('Standardized parameters')
set(gca,'XTick',x,'XTickLabel',patname,'xticklabelrotation',70)
legend('Location','SouthEast')
axis([0,19,-4,4])
set(gca, 'FontSize', 18)
grid on
box on