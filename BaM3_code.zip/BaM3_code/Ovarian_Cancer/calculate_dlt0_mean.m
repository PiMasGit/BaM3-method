% 2 cell pop model
for ipat = 1:Npat
        
    % Loop over the param space
    for ix = 1:length(x_range)

            x_t0 = x_range(ix);

            S1pR1mT1 = @(x,p) p(3)*p(1)*(1 - p(4)/((1-p(5))*x + p(4))) * exp((p(6) - x - p(4)) * p(7)) ...
                              + ((1-p(3))*p(1) + (p(4)*p(3)*p(1)) / ((1-p(5))*x + p(4))) * exp((p(6) - p(5)*x) * p(7)) - p(2) ;  % parameterized function

            p = [T0(ipat) T1(ipat) x_t0 tau lmb gmm t1];                    % parameters
        
            fun_to_opt = @(x) S1pR1mT1(x,p);    % function of x alone
        
            dlt0_opt_mat(ix,ipat) = fzero(fun_to_opt,1.);            

            %clear temp_S0 temp_R0 temp_exp1 temp_exp2 temp_S1 temp_R1 temp_S2 temp_R2 temp_Sd temp_Rd
    end   

end

dlt0_mean = mean(mean(dlt0_opt_mat));