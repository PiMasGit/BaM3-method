%-------------------------------------------------------------------------%
%  Application of the BaM3 method to a dataset of ovarian cancer patients %
%                                                                         %
%  Pietro Mascheroni                                                      %
%                                                                         %
%  E-Mail: pietro.mascheroni@helmholtz-hzi.de                             %
%                                                                         %
%  Requires mvksdensity.m from the 'Statistics and Machine Learning       %
%  Toolbox'                                                               %
%                                                                         %  
%  We use data from the following study:                                  %  
%  Koz?owska, Emilia, et al. "Mathematical modeling predicts response to  %
%  chemotherapy and drug combinations in ovarian cancer."                 %   
%  Cancer research 78.14 (2018): 4036-4044.                               %
%-------------------------------------------------------------------------%

clear
close all

% Load the dataset
load age_pfi_t0_t1.mat

% Note: PFI is used in the code instead of TtR (used in the main text) for
% consistency with the dataset

% Extract the information from the dataset
PFI = age_pfi_t0_t1(:,2); 
age = age_pfi_t0_t1(:,1);
T0  = age_pfi_t0_t1(:,3);
T1  = age_pfi_t0_t1(:,4);

% Find the number of patients
Npat = size(age_pfi_t0_t1,1);

%% Mathematical model
% Parameters (taken from the Cancer Res paper)
gmm = 5.8e-3; % net growth rate [d^-1]
t1 = 63; % duration of first cycle of treatment [d]
beta = 0.01; % tumor reduction due to surgery
td = 63 * 2; % duration of therapy [d]
TR = 1.; % tumor cell number at relapse [cm^3]
lmb = 0.01; % resistance effect on therapy for R cells
tau = 1.6e-5; % [d^-1]

pdf_disc = 100; % Define the discretization of the modelable pdf
PFI_range = linspace(0,24,pdf_disc);

disc_range = 300; % Define the discretization of the parameter space
x_range = linspace(0.4, 0.9, disc_range);


%% First case - unknown dlt0
dlt0_range = linspace(0.1, 10, disc_range); 

for ipat = 1:Npat % Loop over the patient ensemble
    
    temp_Td = zeros(length(dlt0_range), length(x_range));
    
    for id = 1:length(dlt0_range) % Loop over the param space
        for ix = 1:length(x_range)
                
                x_t0 = x_range(ix); 
                dlt0 = dlt0_range(id);

                temp_S0 = x_t0 * T0(ipat);
                temp_R0 = (1 - x_t0) * T0(ipat);

                temp_exp1 = gmm - lmb * dlt0;
                temp_exp2 = gmm - dlt0 - tau;

                temp_S1 = temp_S0 * exp( temp_exp2 * t1);
                temp_R1 = (temp_R0 + tau*temp_S0/((1-lmb)*dlt0 + tau)) * exp(temp_exp1 * t1) - tau*temp_S0/((1-lmb)*dlt0 + tau) * exp(temp_exp2 * t1);

                temp_S2 = beta * temp_S1;
                temp_R2 = beta * temp_R1;

                temp_Sd = temp_S2 * exp(temp_exp2 * (td-t1));
                temp_Rd = (temp_R2 + tau*temp_S2/((1-lmb)*dlt0 + tau)) * exp(temp_exp1 * (td-t1)) - tau*temp_S2/((1-lmb)*dlt0 + tau) * exp(temp_exp2 * (td-t1));

                temp_Td(id,ix) = temp_Sd + temp_Rd;
                
        end   
    end
    
    temp_Td_col = temp_Td(:);
        
    temp_pdf = histcounts(1/30 * 1/gmm * log( TR./temp_Td_col ), linspace(0,24,pdf_disc+1)); % Calculate the modelable pdf by histcounts
    modpdf_un{ipat} = temp_pdf ./ trapz(PFI_range, temp_pdf); % Normalize the pdf
    
end

%% Second case - parametrized death rate

calculate_dlt0_mean; % Run a script to find the mean death rate across patients
pmvar = 0.4; % Select the variation around the mean value to build the distribution of the death rate
dlt0_range = linspace(dlt0_mean*(1-pmvar), dlt0_mean*(1+pmvar), disc_range); 


for ipat = 1:Npat % Loop over the patient ensemble
    
    temp_Td = zeros(length(dlt0_range), length(x_range));
    
    for id = 1:length(dlt0_range) % Loop over the param space
        for ix = 1:length(x_range)
                
                x_t0 = x_range(ix); 
                dlt0 = dlt0_range(id);

                temp_S0 = x_t0 * T0(ipat);
                temp_R0 = (1 - x_t0) * T0(ipat);

                temp_exp1 = gmm - lmb * dlt0;
                temp_exp2 = gmm - dlt0 - tau;

                temp_S1 = temp_S0 * exp( temp_exp2 * t1);
                temp_R1 = (temp_R0 + tau*temp_S0/((1-lmb)*dlt0 + tau)) * exp(temp_exp1 * t1) - tau*temp_S0/((1-lmb)*dlt0 + tau) * exp(temp_exp2 * t1);

                temp_S2 = beta * temp_S1;
                temp_R2 = beta * temp_R1;

                temp_Sd = temp_S2 * exp(temp_exp2 * (td-t1));
                temp_Rd = (temp_R2 + tau*temp_S2/((1-lmb)*dlt0 + tau)) * exp(temp_exp1 * (td-t1)) - tau*temp_S2/((1-lmb)*dlt0 + tau) * exp(temp_exp2 * (td-t1));

                temp_Td(id,ix) = temp_Sd + temp_Rd;
                
        end   
    end
    
    temp_Td_col = temp_Td(:);
        
    temp_pdf = histcounts(1/30 * 1/gmm * log( TR./temp_Td_col ), linspace(0,24,pdf_disc+1));
    modpdf_dm{ipat} = temp_pdf ./ trapz(PFI_range, temp_pdf); 
    
end



%% Calculate the unmodelable pdf
DbYXu = [PFI, age]; % build the dataset for the KDE

bw1 = std(DbYXu(:,1)) .* (4 / (Npat .* (size(DbYXu,2) + 2) ) ) .^ (1 / (size(DbYXu,2) + 4)); % define the bandwidth according to Silverman's rule
bw2 = std(DbYXu(:,2)) .* (4 / (Npat .* (size(DbYXu,2) + 2) ) ) .^ (1 / (size(DbYXu,2) + 4));

pts_Y = ndgrid(PFI_range); % find the point in which the KDE is evaluated for each patient

for i = 1:Npat % loop over the patients

    % find the points for which we want the KDE to be evaluated
    pts_YXustar = [pts_Y, DbYXu(i,2) * ones(size(pts_Y,1),1)]; % we want to call the KDE over all the PFI_range, for each patient

    % Use mvksdensity to calculate the KDE
    temp2 = mvksdensity(DbYXu, pts_YXustar, 'Bandwidth', [bw1 bw2]);

    % Normalize the distribution
    unmodpdf{i} = temp2 ./ trapz(PFI_range, temp2);     

end

 
%% Build the BaM3 distributions
for i = 1:Npat

    % Calculate the corrected probability distribution and normalize it
    temp3 = unmodpdf{i} .* modpdf_un{i}';
    BaM3pdf_un{i} = temp3 ./ trapz(PFI_range, temp3);
    
    temp4 = unmodpdf{i} .* modpdf_dm{i}';
    BaM3pdf_dm{i} = temp4 ./ trapz(PFI_range, temp4);

end



%% Calculate the expected value, mode and median of the distributions 
for i = 1:Npat
    
    % Mode from the model_un pdf
    [~,idxM] = max(modpdf_un{i}); % find the index of the mode
    M_PFI_mod_un(i) = PFI_range(idxM); % calculate the mode   

    % Mode from the model_dm pdf
    [~,idxM] = max(modpdf_dm{i}); % find the index of the mode
    M_PFI_mod_dm(i) = PFI_range(idxM); % calculate the mode       
    
    % Mode from the BaM3_un pdf
    [~,idxM] = max(BaM3pdf_un{i}); % find the index of the mode
    M_PFI_bam3_un(i) = PFI_range(idxM); % calculate the mode  
    
    % Mode from the BaM3_dm pdf
    [~,idxM] = max(BaM3pdf_dm{i}); % find the index of the mode
    M_PFI_bam3_dm(i) = PFI_range(idxM); % calculate the mode  
    
    % Mode from the unmodelable pdf
    [~,idxM] = max(unmodpdf{i}); % find the index of the mode
    M_PFI_unmod(i) = PFI_range(idxM); % calculate the mode 
end


%% Calculate the error for the expected value, mode and median
MSE_M_mod_un = 1/Npat * ( sum( (PFI' - M_PFI_mod_un).^2 ) );
MSE_M_mod_dm = 1/Npat * ( sum( (PFI' - M_PFI_mod_dm).^2 ) );

MSE_M_bam3_un = 1/Npat * ( sum( (PFI' - M_PFI_bam3_un).^2 ) );
MSE_M_bam3_dm = 1/Npat * ( sum( (PFI' - M_PFI_bam3_dm).^2 ) );

MSE_M_unmod = 1/Npat * ( sum( (PFI' - M_PFI_unmod).^2 ) );

fprintf('\n\nMSE_M_mod_un = %.3f \tMSE_M_mod_dm = %.3f', MSE_M_mod_un, MSE_M_mod_dm);
fprintf('\n\nMSE_M_bam_un = %.3f \tMSE_M_bam_dm = %.3f', MSE_M_bam3_un, MSE_M_bam3_dm);
fprintf('\n\nMSE_M_unmod = %.3f\n', MSE_M_unmod);

save('MSE_fitted_bam3.mat','M_PFI_bam3_dm')


%% Show the calculated pdfs 
figure('Name','Pdfs unknown dlt0') % Figure S13
for i=1:Npat
    subplot(4,5,i)
    hold on
    plot(PFI_range, modpdf_un{i},'-', 'LineWidth', 2)
    plot(PFI_range, unmodpdf{i},'-', 'LineWidth', 2)
    plot(PFI_range, BaM3pdf_un{i},'-', 'LineWidth', 2)
    if i==1 % plot the legend only for the first subplot
        legend('Model','Data','BaM^3')
        legend('Location','NorthWest')
    end
    line([PFI(i),PFI(i)],[0,0.25],'Color','red','LineWidth',2,'LineStyle','--')
    xlabel('TtR [months]')
    ylabel('Pdfs')
    title(sprintf('Patient %d', i))
    box on
    set(gca, 'FontSize', 18);
    axis([0,24,0,0.25])
end


figure('Name','Pdfs mean dlt0') % Figure S14
for i=1:Npat
    subplot(4,5,i)
    hold on
    plot(PFI_range, modpdf_dm{i},'-', 'LineWidth', 2)
    plot(PFI_range, unmodpdf{i},'-', 'LineWidth', 2)
    plot(PFI_range, BaM3pdf_dm{i},'-', 'LineWidth', 2)
    if i==1 % plot the legend only for the first subplot
        legend('Model','Data','BaM^3')
        legend('Location','NorthWest')
    end
    line([PFI(i),PFI(i)],[0,0.25],'Color','red','LineWidth',2,'LineStyle','--')
    xlabel('TtR [months]')
    ylabel('Pdfs')
    title(sprintf('Patient %d', i))
    box on
    set(gca, 'FontSize', 18);
    axis([0,24,0,0.25])
end


%% Show predicted vs real values (Figure 7A)
figure('Name','Predictions - Fitted')
hold on
scatter(PFI,M_PFI_mod_dm,'filled')
scatter(PFI,M_PFI_unmod,'filled')
scatter(PFI,M_PFI_bam3_dm,'filled')
legend('Model','Data','BaM^3')
plot(linspace(0,max(PFI),100),linspace(0,max(PFI),100),'--','Color',[0.5 0.5 0.5])
axis square
set(gca, 'FontSize', 18);
xlabel('real PFI [months]')
ylabel('predicted PFI [months]')
title('\rmModel vs BaM^3')
box on

%% Show particular patients (Figure 7B)
ref_pat = [2,9];

figure
for i=1:length(ref_pat)
    subplot(length(ref_pat),1,i)
    hold on
    plot(PFI_range, modpdf_dm{ref_pat(i)},'-', 'LineWidth', 2)
    plot(PFI_range, unmodpdf{ref_pat(i)},'-', 'LineWidth', 2)
    plot(PFI_range, BaM3pdf_dm{ref_pat(i)},'-', 'LineWidth', 2)
    if i==1 % plot the legend only for the first subplot
        legend('Model','Data','BaM^3')
        legend('Location','NorthEast')
    end
    line([PFI(ref_pat(i)),PFI(ref_pat(i))],[0,0.25],'Color','red','LineWidth',2,'LineStyle','--')
    xlabel('TtR [months]')
    ylabel('Pdfs')
    title(sprintf('Patient %d', ref_pat(i)))
    box on
    set(gca, 'FontSize', 18);
    axis([0,24,0,0.15])
end

%% Perform the analysis using a simplified model
simple_model
