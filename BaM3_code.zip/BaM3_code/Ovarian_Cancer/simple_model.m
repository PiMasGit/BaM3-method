% Perform the analysis over the ovarian cancer patients using a simplified 
% mathematical model

clear

% Load the database of patients
load age_pfi_t0_t1.mat

PFI = age_pfi_t0_t1(:,2);
age = age_pfi_t0_t1(:,1);
T0  = age_pfi_t0_t1(:,3);
T1  = age_pfi_t0_t1(:,4);

Npat = size(age_pfi_t0_t1,1);

%% Mathematical model
% Parameters (taken from the Cancer Res paper)
gmm = 5.8e-3; % net growth rate [d^-1]
t1 = 63; % duration of first cycle of treatment [d]
beta = 0.01; % tumor reduction due to surgery
td = 63 * 2; % duration of therapy [d]
TR = 1.; % tumor cell number at relapse [cm^3]
lmb = 0.01; % resistance effect on therapy for R cells
tau = 1.6e-5; % [d^-1]

pdf_disc = 100; % Discretization of the modelable pdf
PFI_range = linspace(0,24,pdf_disc);

dlt1_vec = gmm + 1/t1 * log( T0 ./ T1); % find the value of the death rate after the first round of chemotherapy for each patient
dlt1_mean = mean(dlt1_vec);

disc_range = 1e5; % Discretization of the parameter space
pmvar = 0.5;
dlt0_range = linspace(dlt1_mean*(1-pmvar), dlt1_mean*(1+pmvar), disc_range);

%% Calculate the modelable pdf
for i=1:Npat
    
    PFI_simp{i} = 1/30 * (1/gmm * log(TR / T0(i)) + td/gmm .* dlt0_range - td); % the factor 1/30 is to account for days -> months
    temp = histcounts(PFI_simp{i}, linspace(0,24,pdf_disc+1)); % calculate the modelable pdf by counting the number of occurences
    modpdf_simp{i} = temp ./ trapz(PFI_range, temp);

end



%% Unmodelables
% Build the unmodelable pdf 
DbYXu = [PFI, age]; % build the dataset for the KDE

bw1 = std(DbYXu(:,1)) .* (4 / (Npat .* (size(DbYXu,2) + 2) ) ) .^ (1 / (size(DbYXu,2) + 4)); % define the bandwidth according to Silverman's rule
bw2 = std(DbYXu(:,2)) .* (4 / (Npat .* (size(DbYXu,2) + 2) ) ) .^ (1 / (size(DbYXu,2) + 4));

pts_Y = ndgrid(PFI_range); % find the point in which the KDE is evaluated for each patient

for i = 1:Npat % loop over the patients

    % find the points for which we want the KDE to be evaluated
    pts_YXustar = [pts_Y, DbYXu(i,2) * ones(size(pts_Y,1),1)]; % we want to call the KDE over all the PFI_range, for each patient

    % Use mvksdensity to calculate the KDE
    temp2 = mvksdensity(DbYXu, pts_YXustar, 'Bandwidth', [bw1 bw2]);

    % Normalize the distribution
    unmodpdf{i} = temp2 ./ trapz(PFI_range, temp2);     

end

 
%% Build the BaM3 distributions
for i = 1:Npat

    % Calculate the corrected probability distribution and normalize it
    temp3 = unmodpdf{i} .* modpdf_simp{i}';
    BaM3pdf_simp{i} = temp3 ./ trapz(PFI_range, temp3);

end

 
%% Calculate the expected value, mode and median of the distributions 
for i = 1:Npat
    
    % Exp value from the model pdf
    E_PFI_mod_simp(i) = trapz(PFI_range, PFI_range .* modpdf_simp{i});
    
    % Exp value from the bam pdf
    E_PFI_bam3_simp(i) = trapz(PFI_range, PFI_range' .* BaM3pdf_simp{i});
    
    % Mode from the model pdf
    [~,idxM] = max(modpdf_simp{i}); % find the index of the mode
    M_PFI_mod_simp(i) = PFI_range(idxM); % calculate the mode   

    % Mode from the BaM3 pdf
    [~,idxM] = max(BaM3pdf_simp{i}); % find the index of the mode
    M_PFI_bam3_simp(i) = PFI_range(idxM); % calculate the mode     

end



%% Calculate the error for the expected value, mode and median
MSE_M_mod_simp = 1/Npat * ( sum( (PFI' - M_PFI_mod_simp).^2 ) );
MSE_E_mod_simp = 1/Npat * ( sum( (PFI' - E_PFI_mod_simp).^2 ) );

MSE_M_bam3_simp = 1/Npat * ( sum( (PFI' - M_PFI_bam3_simp).^2 ) );
MSE_E_bam3_simp = 1/Npat * ( sum( (PFI' - E_PFI_bam3_simp).^2 ) );

fprintf('\n\nMSE_M_mod = %.3f \tMSE_E_mod = %.3f', MSE_M_mod_simp, MSE_E_mod_simp);
fprintf('\n\nMSE_M_bam = %.3f \tMSE_E_bam = %.3f\n\n', MSE_M_bam3_simp, MSE_E_bam3_simp);



%% Plot the pdfs (Figure S15)
figure('Name','Pdfs simple model')
for i=1:Npat
    subplot(4,5,i)
    hold on
    plot(PFI_range, modpdf_simp{i},'-', 'LineWidth', 2)
    plot(PFI_range, unmodpdf{i},'-', 'LineWidth', 2)
    plot(PFI_range, BaM3pdf_simp{i},'-', 'LineWidth', 2)
    if i==1 % plot the legend only for the first subplot
        legend('Model','Data','BaM^3')
        legend('Location','NorthWest')
    end
    line([PFI(i),PFI(i)],[0,0.25],'Color','red','LineWidth',2,'LineStyle','--')
    xlabel('TtR [months]')
    ylabel('Pdfs')
    title(sprintf('Patient %d', i))
    box on
    set(gca, 'FontSize', 18);
    axis([0,24,0,0.25])
end

