function genDT_tser(fki,fke,Np)

    %---------------------------------------------------------------------%
    %#####################################################################%
    %---------------------------------------------------------------------%
    
    L     = 300;    %=> (mm) length of the domain
    xh    = 2.5e-2; %=> (mm) spatial discretization
    xmesh = 0:xh:L; %=> Discretized spatial domain

    % Parameters for the FK model
    D_list = [0.0273000, 0.088725, 0.1501500, 0.2115750, 0.2730000];
    b_list = [0.00273000, 0.0088725, 0.01501500, 0.02115750, 0.02730000];
    
    % Create a finer grid in the parameter space
    [Dl_interp, bl_interp] = meshgrid(D_list(1,1):((D_list(1,end) - D_list(1,1)) / 50):D_list(1,end), ...
                                      b_list(1,1):((b_list(1,end) - b_list(1,1)) / 50):b_list(1,end));
    
    %---------------------------------------------------------------------%
    
    NSiml = Np;
    
    % set t_0
    fk_icond = fki;   
    % set t_p
    fk_econd = fke; 
    
    % Generate a random vector including the times of diagnosis t_d
    %rng(10); % for reproducibility
    td_vec = randi([fki-6 fki+6],NSiml,1); % random time between [fki-6m, fki+6m] 
    
    %---------------------------------------------------------------------%
    %#####################################################################%
    %---------------------------------------------------------------------%

        for i = 1:NSiml

            simul_pdesys = load(strcat('CREATE_DATASET/DATASET/Simulations_pdesys/simulation_pdesys_', num2str(i), '.mat'), ...
                                       'c',  ...
                                       'n',  ...
                                       'v',  ...
                                       'Dc', ...
                                       'bc', ...
                                       'as', ...
                                       'bs', ...
                                       'h2', ...
                                       'g1', ...
                                       'g2');

            %-------------------------------------------------------------%

            tfl_ec(1,i) = func_InfiltrationWidth(simul_pdesys.c((fk_icond + fk_econd),:), xmesh); % Calculate IW and TS for the 'reality' case (full model)
            tms_ec(1,i) = func_Mass(simul_pdesys.c((fk_icond + fk_econd),:), xmesh);

            %-------------------------------------------------------------%
            % Calculate the metrics that will be used to populate the
            % dataset (Y, Xu) at t0 and td
            
            tfl_icond(1,i) = func_InfiltrationWidth(simul_pdesys.c(fk_icond,:), xmesh);
            tms_icond(1,i) = func_Mass(simul_pdesys.c(fk_icond,:), xmesh);
            nms_icond(1,i) = func_metric(simul_pdesys.n(fk_icond,:), xmesh);
            vms_icond(1,i) = func_metric(simul_pdesys.v(fk_icond,:), xmesh);
            
            tfl_td(1,i) = func_InfiltrationWidth(simul_pdesys.c(td_vec(i),:), xmesh);
            tms_td(1,i) = func_Mass(simul_pdesys.c(td_vec(i),:), xmesh);
            nms_td(1,i) = func_metric(simul_pdesys.n(td_vec(i),:), xmesh);
            vms_td(1,i) = func_metric(simul_pdesys.v(td_vec(i),:), xmesh);

            %-------------------------------------------------------------%

            tfl_mec{1,i} = zeros(length(D_list), length(b_list));
            tms_mec{1,i} = zeros(length(D_list), length(b_list));
            
            tfl_mec_interp{1,i} = interp2(D_list, b_list, zeros(length(D_list),length(b_list)), Dl_interp, bl_interp, 'cubic');
            tms_mec_interp{1,i} = interp2(D_list, b_list, zeros(length(D_list),length(b_list)), Dl_interp, bl_interp, 'cubic');
            
            clearvars simul_pdesys;

        end
        
        % Save results
        save(strcat('DTfiles_nv/fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), 'DT.mat'),...
            'tfl_ec', ...
            'tms_ec', ...
            'tfl_mec', ... 
            'tms_mec', ... 
            'tfl_mec_interp', ...
            'tms_mec_interp', ...
            'tfl_icond', ...
            'tms_icond', ...
            'nms_icond', ...
            'vms_icond', ...
            'tfl_td', ...
            'tms_td', ...
            'nms_td', ...
            'vms_td');
    
%#########################################################################%

    function [tfl] = func_InfiltrationWidth(vals, xmesh)
        
        for k = 1:length(vals)
            if(vals(1,k) >= (0.80 * max(vals)))
                ind80 = k;
            end
        end

        for k = length(vals):-1:1
            if(vals(1,k) <= (0.02 * max(vals)))
                ind02 = k;
            end
        end
        
        tfl = xmesh(1,ind02) - xmesh(1,ind80);
    end

%#########################################################################%

    function [mass] = func_Mass(vals, xmesh)
        mass = trapz(xmesh, vals/max(vals));
    end

%#########################################################################%

    function [metric] = func_metric(vals, xmesh)
        metric = trapz(xmesh, vals); 
    end

%#########################################################################%
end