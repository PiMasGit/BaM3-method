function plot_fail_cases()

fz = 22; % Select fontsize

uncs = 'nv';

alpha = 0.05;

thr = 0.05;
tec_vec = [1, 3, 6, 9, 12]; % Vector of t_p
pval_vec = [0.01, 0.025, 0.05, 0.075, 0.1]; % Vector of alpha values

load('./CREATE_DATASET/Dlist.txt');
load('./CREATE_DATASET/blist.txt');
load('./CREATE_DATASET/g1list.txt');
load('./CREATE_DATASET/g2list.txt');
load('./CREATE_DATASET/h2list.txt');

%% Fig 4
figure('Name','\DeltaIW,\DeltaTM, t_0=12[months]'),
fk_icond = 13;
for itp = 1:length(tec_vec)
    tp = tec_vec(itp);

    load(strcat('./scores_', uncs, '/Scores_thr', num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'Df', 'Dq', 'Seq', 'Sim', 'Sde', 'pval_vec', 'tec_vec');
    ide13 = find(Df{pval_vec==alpha,tec_vec==tp}(:) > (1 + thr) * Dq{pval_vec==alpha,tec_vec==tp}(:));    % Deterioration of prediction
    
    load(strcat('./scores_', uncs, '/Scores_TMqfIWqf_thr', num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'DTMq', 'DTMf', 'DIWq', 'DIWf');
    
    subplot(2,5,itp)
    temp1 = DIWq{pval_vec==alpha,tec_vec==tp};
    temp2 = DIWf{pval_vec==alpha,tec_vec==tp};
    temp1(ide13)=[];
    temp2(ide13)=[];
    scatter(temp1,temp2),
    hold on
    scatter(DIWq{pval_vec==alpha,tec_vec==tp}(ide13),DIWf{pval_vec==alpha,tec_vec==tp}(ide13),'r');
    plot(linspace(min(DIWq{pval_vec==alpha,tec_vec==tp}),max(DIWq{pval_vec==alpha,tec_vec==tp}),100), linspace(min(DIWq{pval_vec==alpha,tec_vec==tp}),max(DIWq{pval_vec==alpha,tec_vec==tp}),100), '--');
    axis square
    xlabel('\DeltaIW_m')
    ylabel('\DeltaIW_b')
    set(gca,'FontSize',fz);
    axis(1.1*[min(DIWq{pval_vec==alpha,tec_vec==tp}),max(DIWq{pval_vec==alpha,tec_vec==tp}),min(DIWq{pval_vec==alpha,tec_vec==tp}),max(DIWq{pval_vec==alpha,tec_vec==tp})])
    box on
    
    clear temp1 temp2
    subplot(2,5,5+itp)
    temp1 = DTMq{pval_vec==alpha,tec_vec==tp};
    temp2 = DTMf{pval_vec==alpha,tec_vec==tp};
    temp1(ide13)=[];
    temp2(ide13)=[];
    scatter(temp1,temp2),
    hold on
    scatter(DTMq{pval_vec==alpha,tec_vec==tp}(ide13),DTMf{pval_vec==alpha,tec_vec==tp}(ide13),'r');
    plot(linspace(min(DTMq{pval_vec==alpha,tec_vec==tp}),max(DTMq{pval_vec==alpha,tec_vec==tp}),100), linspace(min(DTMq{pval_vec==alpha,tec_vec==tp}),max(DTMq{pval_vec==alpha,tec_vec==tp}),100), '--');
    axis square
    xlabel('\DeltaTS_m')
    ylabel('\DeltaTS_b')
    set(gca,'FontSize',fz);
    axis(1.1*[min(DTMq{pval_vec==alpha,tec_vec==tp}),max(DTMq{pval_vec==alpha,tec_vec==tp}),min(DTMq{pval_vec==alpha,tec_vec==tp}),max(DTMq{pval_vec==alpha,tec_vec==tp})])
    box on   

end


%
clear Df Dq DTMq DTMf DIWq DIWf temp1 temp2

figure('Name','\DeltaIW, \DeltaTM, t_0 = 24 [months]'),
fk_icond = 25;
for itp = 1:length(tec_vec)
    tp = tec_vec(itp);

    load(strcat('./scores_', uncs, '/Scores_thr', num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'Df', 'Dq', 'Seq', 'Sim', 'Sde', 'pval_vec', 'tec_vec');
    ide25 = find(Df{pval_vec==alpha,tec_vec==tp}(:) > (1 + thr) * Dq{pval_vec==alpha,tec_vec==tp}(:));    % Deterioration of prediction
    
    load(strcat('./scores_', uncs, '/Scores_TMqfIWqf_thr', num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'DTMq', 'DTMf', 'DIWq', 'DIWf');
    
    subplot(2,5,itp)
    temp1 = DIWq{pval_vec==alpha,tec_vec==tp};
    temp2 = DIWf{pval_vec==alpha,tec_vec==tp};
    temp1(ide25)=[];
    temp2(ide25)=[];
    scatter(temp1,temp2),
    hold on
    scatter(DIWq{pval_vec==alpha,tec_vec==tp}(ide25),DIWf{pval_vec==alpha,tec_vec==tp}(ide25),'r');
    plot(linspace(min(DIWq{pval_vec==alpha,tec_vec==tp}),max(DIWq{pval_vec==alpha,tec_vec==tp}),100), linspace(min(DIWq{pval_vec==alpha,tec_vec==tp}),max(DIWq{pval_vec==alpha,tec_vec==tp}),100), '--');
    axis square
    xlabel('\DeltaIW_m')
    ylabel('\DeltaIW_b')
    %title(sprintf('\\rm t_0=12, t_p = %d [m]',tp));
    set(gca,'FontSize',fz);
    axis(1.1*[min(DIWq{pval_vec==alpha,tec_vec==tp}),max(DIWq{pval_vec==alpha,tec_vec==tp}),min(DIWq{pval_vec==alpha,tec_vec==tp}),max(DIWq{pval_vec==alpha,tec_vec==tp})])
    box on
    
    clear temp1 temp2
    subplot(2,5,5+itp)
    temp1 = DTMq{pval_vec==alpha,tec_vec==tp};
    temp2 = DTMf{pval_vec==alpha,tec_vec==tp};
    temp1(ide25)=[];
    temp2(ide25)=[];
    scatter(temp1,temp2),
    hold on
    scatter(DTMq{pval_vec==alpha,tec_vec==tp}(ide25),DTMf{pval_vec==alpha,tec_vec==tp}(ide25),'r');
    plot(linspace(min(DTMq{pval_vec==alpha,tec_vec==tp}),max(DTMq{pval_vec==alpha,tec_vec==tp}),100), linspace(min(DTMq{pval_vec==alpha,tec_vec==tp}),max(DTMq{pval_vec==alpha,tec_vec==tp}),100), '--');
    axis square
    xlabel('\DeltaTS_m')
    ylabel('\DeltaTS_b')
    %title(sprintf('\\rm t_0=12, t_p = %d [m]',tp));
    set(gca,'FontSize',fz);
    axis(1.1*[min(DTMq{pval_vec==alpha,tec_vec==tp}),max(DTMq{pval_vec==alpha,tec_vec==tp}),min(DTMq{pval_vec==alpha,tec_vec==tp}),max(DTMq{pval_vec==alpha,tec_vec==tp})])
    box on   

end

%% Figure S5
figure('Name','t_0 = 12 (top) vs 24 (bottom) [months]'),
for itp = 1:length(tec_vec)
    tp = tec_vec(itp);

    fk_icond = 13;
    load(strcat('./scores_', uncs, '/Scores_thr', num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'Df', 'Dq', 'Seq', 'Sim', 'Sde', 'pval_vec', 'tec_vec');
    ide13 = find(Df{pval_vec==alpha,tec_vec==tp}(:) > (1 + thr) * Dq{pval_vec==alpha,tec_vec==tp}(:));    % Deterioration of prediction
    ide13_vec{itp,1} = ide13;
    
    fk_icond = 25;
    load(strcat('./scores_', uncs, '/Scores_thr', num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_', tec_vec), '.mat'), 'Df', 'Dq', 'Seq', 'Sim', 'Sde', 'pval_vec', 'tec_vec');
    ide25 = find(Df{pval_vec==alpha,tec_vec==tp}(:) > (1 + thr) * Dq{pval_vec==alpha,tec_vec==tp}(:));    % Deterioration of prediction
    ide25_vec{itp,1} = ide25;
    
    subplot(2,5,itp)
    scatter(Dlist,blist),
    hold on
    scatter(Dlist(ide13),blist(ide13),'r');
    axis square
    axis([0,0.3,0,0.03])
    xlabel('D [mm^2/d]')
    ylabel('b [1/d]')
    title(sprintf('\\rm t_0=12, t_p = %d [m]',tp));
    set(gca,'FontSize',fz)
    set(gca,'XTick',[0,0.1,0.2,0.3])
    box on

    subplot(2,5,5+itp)
    scatter(Dlist,blist),
    hold on
    scatter(Dlist(ide25),blist(ide25),'r');
    axis square
    axis([0,0.3,0,0.03])
    xlabel('D [mm^2/d]')
    ylabel('b [1/d]')
    title(sprintf('\\rm t_0=24, t_p = %d [m]',tp));
    set(gca,'FontSize',fz)
    set(gca,'XTick',[0,0.1,0.2,0.3])
    box on
    
end
 
%% Fig S6 
figure('Name','t_0 = 12 (top) vs 24 (bottom) [months]'),

for itp = 1:length(tec_vec)
    tp = tec_vec(itp);


    fk_icond = 13; load(strcat('./scores_', uncs, '/Scores_thr',num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_',tec_vec), '.mat'), 'Df', 'Dq', 'Seq', 'Sim', 'Sde', 'pval_vec','tec_vec');
    ide13 = find(Df{pval_vec==alpha,tec_vec==tp}(:) > (1 +thr) * Dq{pval_vec==alpha,tec_vec==tp}(:));    % Deterioration of prediction

    fk_icond = 25; load(strcat('./scores_', uncs, '/Scores_thr',num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_',tec_vec), '.mat'), 'Df', 'Dq', 'Seq', 'Sim', 'Sde', 'pval_vec','tec_vec'); 
    ide25 = find(Df{pval_vec==alpha,tec_vec==tp}(:) > (1 +thr) * Dq{pval_vec==alpha,tec_vec==tp}(:));    % Deterioration ofprediction


    subplot(2,5,itp) 
    scatter(g1list,1e11*g2list), 
    hold on
    scatter(g1list(ide13),1e11*g2list(ide13),'r'); 
    axis square
    xlabel('g1 [1/d]') 
    ylabel('g2x10^{11} [1/d]') 
    title(sprintf('\\rm t_0=12 [m], t_p=%d [m]',tp));
    set(gca,'FontSize',fz);
    box on
    axis([0,1.05*max(g1list),0,1.05*1e11*max(g2list)])

    subplot(2,5,5+itp) 
    scatter(g1list,1e11*g2list), 
    hold on
    scatter(g1list(ide25),1e11*g2list(ide25),'r');
    axis square
    xlabel('g1 [1/d]') 
    ylabel('g2x10^{11} [1/d]') 
    title(sprintf('\\rm t_0=24 [m], t_p=%d [m]',tp));
    set(gca,'FontSize',fz);
    box on
    axis([0,1.05*max(g1list),0,1.05*1e11*max(g2list)])
    
end

figure('Name','t_0 = 12 (top) vs 24 (bottom) [months]'),

for itp = 1:length(tec_vec)
    tp = tec_vec(itp);


    fk_icond = 13; load(strcat('./scores_', uncs, '/Scores_thr',num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_',tec_vec), '.mat'), 'Df', 'Dq', 'Seq', 'Sim', 'Sde', 'pval_vec','tec_vec');
    ide13 = find(Df{pval_vec==alpha,tec_vec==tp}(:) > (1 +thr) * Dq{pval_vec==alpha,tec_vec==tp}(:));    % Deterioration of prediction

    fk_icond = 25; load(strcat('./scores_', uncs, '/Scores_thr',num2str(thr),'_fki', num2str(fk_icond), '_te', sprintf('%d_',tec_vec), '.mat'), 'Df', 'Dq', 'Seq', 'Sim', 'Sde', 'pval_vec','tec_vec'); 
    ide25 = find(Df{pval_vec==alpha,tec_vec==tp}(:) > (1 +thr) * Dq{pval_vec==alpha,tec_vec==tp}(:));    % Deterioration of prediction


    subplot(2,5,itp)
    scatter(h2list,ones(size(h2list))), 
    hold on
    scatter(h2list(ide13),ones(size(h2list(ide13))),'r');
    axis square 
    axis([0,0.12,0,2])
    xlabel('h2 [1/d]') 
    ylabel('-') 
    title(sprintf('\\rm t_0=12 [m], t_p=%d [m]',tp));
    set(gca,'FontSize',fz);
    box on

    subplot(2,5,5+itp) 
    scatter(h2list,ones(size(h2list))), 
    hold on
    scatter(h2list(ide25),ones(size(h2list(ide25))),'r'); 
    axis square 
    axis([0,0.12,0,2])
    xlabel('h2 [1/d]') 
    ylabel('-') 
    title(sprintf('\\rm t_0=24 [m], t_p=%d [m]',tp));
    set(gca,'FontSize',fz);
    box on

end


end