function [] = pdesys(param_Dc, ...
                     param_bc, ...
                     param_h2, ...
                     param_g1, ...
                     param_g2, ...
                     simul_id)

%-------------------------------------------------------------------------%
%--------------------------> Model Parameters <---------------------------%
%-------------------------------------------------------------------------%

    %=> Glioma Cells
    Dc   = param_Dc;
    bc   = param_bc;
    N    = 1.0e+2;
    lmb1 = 2.0;
    lmb2 = 1.0;

    %=> Oxygen
    Dn   = 1.512e+2;
    n0   = 1.0;
    h1   = 3.37e-1;
    h2   = param_h2;

    %=> Vasculature
    Dv   = 5.0e-4;
    g1   = param_g1;
    g2   = param_g2;
    na   = 2.5e-1;
    dlt  = 6.0;

    as = (lmb1 - n0)/((lmb2 - 1) * n0 + lmb1);
    bs = (lmb2 * n0)/((lmb2 - 1) * n0 + lmb1);

    Dc = Dc / as;
    bc = bc / bs;
    
%-------------------------------------------------------------------------%
%------------------------> Simulation Parameters <------------------------%
%-------------------------------------------------------------------------%

    m     = 0;            %=> 1D problem
    th    = 30;           %=> (days) time discretization 
    Tf    = 3 * 3.60e+2;  %=> (days) Final time of the simulation
    L     = 300;          %=> (mm) length of the domain
    xh    = 2.5e-2;       %=> (mm) spatial discretization
    time  = 0:th:Tf;      %=> Time-steps at which the solutions are returned
    xmesh = 0:xh:L;       %=> Discretized spatial domain

%-------------------------------------------------------------------------%
%--------------------------> Model Simulations <--------------------------%
%-------------------------------------------------------------------------%

    opt = odeset('RelTol', 1e-5, 'AbsTol', 1e-7);
    sol = pdepe(m, @pdesyscoef, @pdesysic, @pdesysbc, xmesh, time, opt);

    c = sol(:,:,1);
    n = sol(:,:,2);
    v = sol(:,:,3);

%-------------------------------------------------------------------------%
    
    save(strcat('DATASET/Simulations_pdesys/simulation_pdesys_', num2str(simul_id), '.mat'), ...
                'c',  ...
                'n',  ...
                'v',  ...
                'Dc', ...
                'bc', ...
                'as', ...
                'bs', ...
                'h2', ...
                'g1', ...
                'g2');
    
%|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||%
%-----------------------> Coefficients for pdepe <------------------------%
%|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||%

    function [csys, fsys, ssys] = pdesyscoef(xmesh, time, u, DuDx)

        %-----------------------------------------------------------------%
        %=> time-derivative terms
        
        csys = [1;1;1];

        %-----------------------------------------------------------------%
        %=> flux terms
        
        f1 = -Dc.*u(1).*lmb1./n0.*lmb2./((lmb1./n0+(lmb2-1).*u(2)).^2).*DuDx(2) + ...
              Dc.*(lmb1/n0-u(2))./(lmb1/n0+(lmb2-1).*u(2)).*DuDx(1);
        f2 = Dn.*DuDx(2);
        f3 = Dv.*DuDx(3);

        %-----------------------------------------------------------------%
        %=> source terms
        
        s1 = bc.*lmb2.*u(2)./(lmb1/n0+(lmb2-1).*u(2)).*u(1).*(1-u(1));
        s2 = h1.*u(3).*(1-u(2))-h2.*N.*u(1).*u(2);
        s3 = g1./(1+exp(2*1.0e+2.*(u(2)-na/n0))).*u(3).*(1-u(3))-g2.*N.^dlt.*u(3).*u(1).^dlt;

        %-----------------------------------------------------------------%
        
        fsys = [f1;f2;f3];
        ssys = [s1;s2;s3];
        
        %-----------------------------------------------------------------%
    end

%|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||%
%-------------------------> Initial Conditions <--------------------------%
%|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||%
    
    function u0 = pdesysic(xmesh)
        
        cic = 40;  %=> (cells/mm) initial condition for cell density
        nic = n0;  %=> (nmol/mm) i.c. for oxygen concentration
        vic = 0.5; %=> (-) i.c. for normalized vascular density
        
        u0 = [cic/N./(1+exp(2*1.0e+1.*(xmesh-0.5)));
              nic/n0;
              vic];
    end

%|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||%
%-------------------------> Boundary Conditions <-------------------------%
%|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||%

    function [pl, ql, pr, qr] = pdesysbc(xl, ul, xr, ur, time)
        
        %=> We impose no-flux BCs for all the variables,
        %   both for x = 0 and x = L.
        
        pl = [0;0;0];
        ql = [1;1;1];
        pr = [0;0;0];
        qr = [1;1;1];
    end

%-------------------------------------------------------------------------%
end