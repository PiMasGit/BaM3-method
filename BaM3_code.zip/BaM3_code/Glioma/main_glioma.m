%-------------------------------------------------------------------------%
%  Application of the BaM3 method to in silico glioma growth              %
%                                                                         %
%  Pietro Mascheroni                                                      %
%                                                                         %
%  E-Mail: pietro.mascheroni@helmholtz-hzi.de                             %
%                                                                         %
%  Requires violinplot.m (https://github.com/bastibe/Violinplot-Matlab)   %
%  and mvksdensity.m from the 'Statistics and Machine Learning Toolbox'   %
%-------------------------------------------------------------------------%

clc
clear
close all

N = 10; % Select the number of patients to build the synthetic dataset

%=> array of t0: 12, 24 months
fki_list=[13, 25];

%=> array of tp: [months]
fke_list=[1, 3, 6, 9, 12];


%% Generate the full model parameters for each patient
gen_pat_data(N);

%% Simulate the database of patients
sim_pat;


%% Build the patient ensemble
for i=1:length(fki_list)
    for f=1:length(fke_list);
        genDT(fki_list(i), fke_list(f), N);
    end
end

%% Calculate the math model pdf
for i=1:length(fki_list)
    for f=1:length(fke_list);
        calculate_step1(fki_list(i), fke_list(f), N);
    end
end

%% Calculate the data-driven pdf
for i=1:length(fki_list)
    for f=1:length(fke_list);
        calculate_step2(fki_list(i), fke_list(f), N);
    end
end

%% Calculate the BaM3 pdf
for i=1:length(fki_list)
    for f=1:length(fke_list);
        calculate_step3(fki_list(i), fke_list(f), N);
    end
end

%% Build the patient ensemble for the time series analysis
fki_list_add = [7, 19, 31];
for i=1:length(fki_list_add)
    genDT_tser(fki_list_add(i), 6, N);
end

%% Calculate the data-driven pdf for the time series analysis
calculate_step2_tser(N);

%% Generate the clinical outputs for the time series analysis
genPAT(N);

%% Generate the scores of the predictions
gen_scores(N);      % Score with expected value
gen_scores2(N);     % Score with mode, calculate effective variance

%% Visualize the results

% plot the pdfs (Figure 3 A - C, Figure S2)
t0_plot = 24;   % select the t0 for the plot [months]
tp_plot = 9;    % select the tp for the plot [months]
id_pat = 0;     % if 0 plots a random patient; otherwise specify the patient number (0<id_pat<=N)
plot_dists(t0_plot+1, tp_plot, N, id_pat);

% plot the error, effective variance and scores (Figure 3, Figure S4)
plot_scores();

% plot the fail cases over the parameter space (Figure 4, Figure S5, S6)
plot_fail_cases();

% plot the time series analysis (Figure 5, Figure S7)
id_pat = 0;     % if 0 plots a random patient; otherwise specify the patient number (0<id_pat<=N)
plot_time_series(N, id_pat);





