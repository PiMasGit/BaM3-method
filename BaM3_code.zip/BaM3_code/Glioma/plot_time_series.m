function plot_time_series(Np,idpatient)

NSiml = Np;

fz = 22; % Select fontsize


load('./CREATE_DATASET/Dlist.txt');
load('./CREATE_DATASET/blist.txt');
load('./CREATE_DATASET/g1list.txt');
load('./CREATE_DATASET/g2list.txt');
load('./CREATE_DATASET/h2list.txt');

load('./PATfiles_nv.mat')


colors = [ 0.00, 0.45, 0.74;  % 
           0.85, 0.33, 0.10;  % 
           0.93, 0.69, 0.13;  % 
           0.49, 0.18, 0.56;  % 
           0.47, 0.67, 0.19;  %
           0.30, 0.75, 0.93]; % 

       
%% Fig 5

% Patient selection
if idpatient == 0
    idpat = randi(NSiml, 1); % Select a random patient
else 
    idpat = idpatient;
end

fk_econd = 6;
tfl_range = 0:((130 - 0) / 200):130; 
tms_range = 0:((130 - 0) / 200):130;

icond_vec = [7,13,19,25,31];

for icond = 1:length(icond_vec)
    
    fk_icond = icond_vec(icond);
    load(strcat('./UNMODELABLE_DISTS_nv_tser/UNMODDIST_fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), '.mat'), 'a');    
    
    figure(18)
    subplot(1,5,icond)
    contourf(tms_range, tfl_range, a{idpat}(:,:)/max(max(a{idpat}(:,:))));
    axis square
    xlabel('Tumor size [mm]');
    ylabel('Infiltration width [mm]');
    title(sprintf('\\rm t_0 = %d [m]', icond_vec(icond)-1));
    set(gca,'FontSize',18)

    
    figure(19)
    subplot(1,2,1)
        set(gca,'FontSize',24)
    hold on
    a_IW = trapz(tms_range,a{idpat},2);
    IWa = trapz(tfl_range, tfl_range .* a_IW'); % Expected IW for a dist
    pIW(icond) = plot(tfl_range,a_IW,'LineWidth',2,'Color',colors(icond,:),'DisplayName',sprintf('t_0 = %d [m]', icond_vec(icond)-1));
    axis square
    xlabel('Infiltration Width [mm]')
    ylabel('$p(\mathbf{x}_u|\hat{\mathbf{y}},\bar{\mathbf{y}})_\mathrm{IW}$','Interpreter','Latex')
    legend(pIW(1:end),'Location','NorthEast')
    hold off
    box on
    
    subplot(1,2,2)
        set(gca,'FontSize',24)
    hold on
    a_TM = trapz(tfl_range,a{idpat},1);
    TMa = trapz(tms_range, tms_range .* a_TM);  % Expected TM for a dist
    pTM(icond) = plot(tfl_range,a_TM,'LineWidth',2,'Color',colors(icond,:),'DisplayName',sprintf('t_0 = %d [m]', icond_vec(icond)-1));
    axis square
    xlabel('Tumor Size [mm]')
    ylabel('$p(\mathbf{x}_u|\hat{\mathbf{y}},\bar{\mathbf{y}})_\mathrm{TS}$','Interpreter','Latex')
    legend(pTM(1:end),'Location','NorthEast')
    hold off
    box on
    
end
figure(18), suptitle(sprintf('Patient ID = %d',idpat));
figure(19), suptitle(sprintf('Patient ID = %d',idpat));


% Calculate the overlap score

% Overlap btw t0 = 12 and 18m
load(strcat('./UNMODELABLE_DISTS_nv_tser/UNMODDIST_fkicond', num2str(13), '_fkecond', num2str(6), '.mat'), 'a');    
a_13 = a;
load(strcat('./UNMODELABLE_DISTS_nv_tser/UNMODDIST_fkicond', num2str(19), '_fkecond', num2str(6), '.mat'), 'a');    
a_19 = a;

IWr_12 = zeros(size(a,2),1);
TMr_12 = zeros(size(a,2),1);
for i = 1:size(a,2)
    
    y1IW = trapz(tms_range,a_13{i},2)';
    y1TM = trapz(tfl_range,a_13{i},1);

    y2IW = trapz(tms_range,a_19{i},2)';
    y2TM = trapz(tfl_range,a_19{i},1);

    y_oIW = [y2IW(y2IW<y1IW) y1IW(y1IW<=y2IW)];
    y_oTM = [y2TM(y2TM<y1TM) y1TM(y1TM<=y2TM)];

    IWr_12(i) = trapz(tfl_range, y_oIW);
    TMr_12(i) = trapz(tms_range, y_oTM);
    
clear y1IW y2IW y1TM y2TM y_oIW y_oTM
end

% Overlap btw t0 = 24 and 30m
load(strcat('./UNMODELABLE_DISTS_nv_tser/UNMODDIST_fkicond', num2str(25), '_fkecond', num2str(6), '.mat'), 'a');    
a_25 = a;
load(strcat('./UNMODELABLE_DISTS_nv_tser/UNMODDIST_fkicond', num2str(31), '_fkecond', num2str(6), '.mat'), 'a');    
a_31 = a;

IWr_24 = zeros(size(a,2),1);
TMr_24 = zeros(size(a,2),1);
for i = 1:size(a,2)
    
    y1IW = trapz(tms_range,a_25{i},2)';
    y1TM = trapz(tfl_range,a_25{i},1);

    y2IW = trapz(tms_range,a_31{i},2)';
    y2TM = trapz(tfl_range,a_31{i},1);

    y_oIW = [y2IW(y2IW<y1IW) y1IW(y1IW<=y2IW)];
    y_oTM = [y2TM(y2TM<y1TM) y1TM(y1TM<=y2TM)];

    IWr_24(i) = trapz(tfl_range, y_oIW);
    TMr_24(i) = trapz(tms_range, y_oTM);
    
clear y1IW y2IW y1TM y2TM y_oIW y_oTM
end

% 
figure('Name','Overlap scores')

subplot(1,2,1)
scatter(TMr_12, IWr_12)
axis square
axis([0,1,0,1])
xlabel('Area of overlap for TS')
ylabel('Area of overlap for IW')
title('\rm Overlap btw 12 and 18 months');
set(gca,'FontSize',24)
box on

subplot(1,2,2)
scatter(TMr_24, IWr_24)
axis square
axis([0,1,0,1])
xlabel('Area of overlap for TS')
ylabel('Area of overlap for IW')
title('\rm Overlap btw 24 and 30 months');
set(gca,'FontSize',24)  
box on



%% Fig S7

figure('Name','TS')
subplot(1,2,1)
scatter(Dlist,blist,TM_ec(:,13)),
    axis square
    axis([0,0.3,0,0.03])
    xlabel('D [mm^2/d]')
    ylabel('b [1/d]')
    title('\rm TS, t_0 = 12 [months]');
    set(gca,'FontSize',fz)
    box on

subplot(1,2,2)
scatter(Dlist,blist,TM_ec(:,25)),
    axis square
    axis([0,0.3,0,0.03])
    xlabel('D [mm^2/d]')
    ylabel('b [1/d]')
    title('\rm TS, t_0 = 24 [months]');
    set(gca,'FontSize',fz)
    box on

% 
figure('Name','IW')
subplot(1,2,1)
scatter(Dlist,blist,IW_ec(:,13)),
    axis square
    axis([0,0.3,0,0.03])
    xlabel('D [mm^2/d]')
    ylabel('b [1/d]')
    title('\rm IW, t_0 = 12 [months]');
    set(gca,'FontSize',fz)
    box on

subplot(1,2,2)
scatter(Dlist,blist,IW_ec(:,25)),
    axis square
    axis([0,0.3,0,0.03])
    xlabel('D [mm^2/d]')
    ylabel('b [1/d]')
    title('\rm IW, t_0 = 24 [months]');
    set(gca,'FontSize',fz)
    box on
    
end