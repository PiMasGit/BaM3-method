function calculate_step2_tser(Np)


    % Select the unmodelable case
    uncs = 'nv';
    
    %---------------------------------------------------------------------%
    %#####################################################################%
    %---------------------------------------------------------------------%
    
   
    % Total number of patients
    NSiml = Np;
    
    % set t_0
    fk_icond_vec = [7, 13, 19, 25, 31]; 
    % set t_p
    fk_econd_vec = 6; 


for ifki = 1:length(fk_icond_vec)       % Loop over t_0 times
for ifke = 1:length(fk_econd_vec)       % Loop over t_p times
    
    fk_icond = fk_icond_vec(ifki);
    fk_econd = fk_econd_vec(ifke);
    
    %---------------------------------------------------------------------%
    %#####################################################################%
    %---------------------------------------------------------------------%
    %%% Load the dataset
    load(strcat('./DTfiles_', uncs, '/fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), 'DT.mat'), 'tfl_ec', 'tms_ec', 'tfl_mec', 'tms_mec', 'tfl_mec_interp', 'tms_mec_interp', 'tfl_icond', 'tms_icond', 'nms_icond', 'vms_icond', 'tfl_td', 'tms_td', 'nms_td', 'vms_td');
    
    
%   %---------------------------------------------------------------------%
%   % STEP 2
%   %---------------------------------------------------------------------%
    
    % Fix the range of values for building the distributions
    mintlf = 0;   
    maxtlf = 130; 
    
    mintms = 0;   
    maxtms = 130; 
    
    tfl_range = mintlf:((maxtlf - mintlf) / 200):maxtlf; % Divide the IW and TS range in 200 bins
    tms_range = mintms:((maxtms - mintms) / 200):maxtms;

    %%% Calculate distribution P(Xu|Y)
    % Dataset = IW, TS, ntd, vtd
    DPYXu = [tfl_td; tms_td; nms_td; vms_td]';

    % Create a grid to evaluate tm and iw in a matrix
    [iwcoord, tmcoord] = ndgrid(tfl_range, tms_range);

    % Put everything in the form of column vectors
    iwcoord = iwcoord(:);
    tmcoord = tmcoord(:);
    
    % Build the points in the (IW, TS) space in which we want the evaluation to be done
    pts_iwtm = [iwcoord, tmcoord];

    % Calculate the bandwidth to evaluate the smoother according to Silverman's rule of thumb -see MATLAB ref page on mvksdensity
    bw1 = std(DPYXu(:,1)) .* (4 / (NSiml .* (size(DPYXu,2) + 2) ) ) .^ (1 / (size(DPYXu,2) + 4));
    bw2 = std(DPYXu(:,2)) .* (4 / (NSiml .* (size(DPYXu,2) + 2) ) ) .^ (1 / (size(DPYXu,2) + 4));
    bw3 = std(DPYXu(:,3)) .* (4 / (NSiml .* (size(DPYXu,2) + 2) ) ) .^ (1 / (size(DPYXu,2) + 4));
    bw4 = std(DPYXu(:,4)) .* (4 / (NSiml .* (size(DPYXu,2) + 2) ) ) .^ (1 / (size(DPYXu,2) + 4));
    
    %hwb = waitbar(0, 'Please wait...'); % Enable to visualize a waiting bar in the GUI
    for i = 1:NSiml % loop over the patients to build the unmodelable pdf structure

        % Concatenate the values of the i-th patient (NOTE: here the Xu are at time t0 !)
        pts_iwtmn0v0 = [pts_iwtm, nms_icond(i) .* ones(size(pts_iwtm,1),1), vms_icond(i) .* ones(size(pts_iwtm,1),1)];

        % Use mvksdensity to obtain the probability for each patient over the TS and IW range
        adist = mvksdensity(DPYXu, pts_iwtmn0v0, 'Bandwidth', [bw1 bw2 bw3 bw4]);

        % Reshape the evaluated probability into a matrix form
        adist_mat = reshape(adist, length(tfl_range), length(tms_range));
        
        % Normalize the distribution
        a{i} = adist_mat ./ trapz(tfl_range,trapz(tms_range,adist_mat,2));
        
        clear pts_iwtmn0v0 adist adist_mat 
        
    %waitbar(i/NSiml, hwb, sprintf('Calculating a - completed: %.2f %%', (100 * i/NSiml)));
    end % end of patient loop
    %close(hwb);
    
    
    %%% Save the a-values
    save(strcat('UNMODELABLE_DISTS_nv_tser/UNMODDIST_fkicond', num2str(fk_icond), '_fkecond', num2str(fk_econd), '.mat'), 'a');
    
        
    clear a q pfin pfin_temp

end      % End t_p times loop
end      % End t_0 times loop
    
    
end